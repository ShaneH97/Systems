﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Linker/Loader***
*** DUE DATE : DEC 5, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the linker loader. ***
********************************************************************/
namespace Patel5
{

    public class ExternalSymbolTable
    {
        public Dictionary<string, int[]> CsList = new Dictionary<string, int[]>();
        public Dictionary<string, int[]> SymbolList = new Dictionary<string, int[]>();
        /********************************************************************
       *** FUNCTION ExternalSymbolTable(Constructor)                     ***
       *********************************************************************
       *** DESCRIPTION : This is dictionary that stores symbollist and controlsect list**
       *** INPUT ARGS :                                                  ***
       *** OUTPUT ARGS : -                                               ***
       *** IN/OUT ARGS : -                                               ***
       *** RETURN : int                                                  ***
       ********************************************************************/
        public ExternalSymbolTable()
        {
            CsList = new Dictionary<string, int[]>();
            SymbolList = new Dictionary<string, int[]>();
        }
    }
}