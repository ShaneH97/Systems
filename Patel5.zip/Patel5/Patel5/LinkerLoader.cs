﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Linker/Loader***
*** DUE DATE : DEC 5, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the linker loader. ***
********************************************************************/
namespace Patel5
{
    public static class Loader
    {
        /********************************************************************
        *** FUNCTION Main                                                 ***
        *********************************************************************
        *** DESCRIPTION : Displays the symbol,csect, memory map           ***
        *** INPUT ARGS :  insturctions                                    ***
        *** OUTPUT ARGS : symboltable                                     ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        public static ExternalSymbolTable PassOne(string[][] programs)
        {
            int CSlength = 0;
            var externalSymbolTable = new ExternalSymbolTable();

            foreach (var program in programs)
            {
                foreach (var instruction in program)
                {
                    if (instruction[0] == 'H')
                    {
                        string CSlabel = instruction.Substring(1, 5);
                        CSlabel = CSlabel.Replace(" ", "");
                        int CSstartAddress = Program.startingCSAddress;
                        CSlength = int.Parse(instruction.Substring(12, 6), NumberStyles.HexNumber);
                        externalSymbolTable.CsList.Add(CSlabel, new int[] { CSstartAddress, CSlength });
                    }
                    else if (instruction[0] == 'D')
                    {
                        int dRecCount = instruction.Substring(1).Length / 10;
                        for (int i = 0; i < dRecCount; i++)
                        {
                            string SymbolLabel = instruction.Substring(i * 10 + 1 + i, 5).Replace(@" ", "");
                            string offset = instruction.Substring(i * 10 + 6 + i, 6);
                            var SymbolOffset = int.Parse(offset, NumberStyles.HexNumber);
                            var SymbolAddress = Program.startingCSAddress + SymbolOffset;
                            externalSymbolTable.SymbolList.Add(SymbolLabel, new int[] { SymbolAddress, SymbolOffset });
                        }
                    }
                    else if (instruction[0] == 'E')
                    {
                        if (instruction.Length > 1)
                        {
                            string executionAddress = instruction.Substring(1, 6);
                            Program.executionAddress = Program.startMemory + int.Parse(executionAddress, NumberStyles.HexNumber);
                        }
                        Program.startingCSAddress += CSlength;
                        Program.length += CSlength;
                    }
                } 
            }
            return externalSymbolTable;
        }
        /********************************************************************
        *** FUNCTION PassTwo                                              ***
        *********************************************************************
        *** DESCRIPTION : Pass 2 of the algorim                           ***
        *** INPUT ARGS :  instructions, symboltable                       ***
        *** OUTPUT ARGS : memorymap                                       ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        public static Dictionary<int, string> PassTwo(string[][] programs, ExternalSymbolTable externalSymbolTable)
        {
            int[] tmpAddress = null;
            int programAddress = Program.startMemory;
            int CSStartAddress = Program.startMemory;
            int CSLength = 0;
            string CSlabel = string.Empty;
            Dictionary<int, string> memoryMap = new Dictionary<int, string>();

            foreach (var program in programs)
            {
                foreach (var instruction in program)
                {
                    if (instruction[0] == 'H')
                    {
                        CSlabel = instruction.Substring(1, 5);
                        CSlabel = CSlabel.Replace(@" ", "");
                        CSLength = int.Parse(instruction.Substring(12, 6), NumberStyles.HexNumber);
                       
                        for (int i = 0; i < CSLength; i++)
                        {
                            memoryMap[i + CSStartAddress] = "UU";

                        }
                    }
                    else if (instruction[0] == 'T')
                    {
                        int Taddress = int.Parse(instruction.Substring(1, 6), NumberStyles.HexNumber);
                        int Tlength = int.Parse(instruction.Substring(7, 2), NumberStyles.HexNumber);
                        string Trecord = instruction.Substring(9, instruction.Length - 9);
                        int memoryAddress = CSStartAddress + Taddress;
                        for (int i = 0; i < Tlength; i++)
                        {
                            memoryMap[memoryAddress] = Trecord.Substring(i * 2, 2);
                            memoryAddress += 1;
                        }
                    }
                    else if (instruction[0] == 'M')
                    {
                        int Maddress = int.Parse(instruction.Substring(1, 6), NumberStyles.HexNumber);
                        int memoryAddress = CSStartAddress + Maddress;

                        string nibbles = memoryMap[memoryAddress] + memoryMap[memoryAddress + 1] + memoryMap[memoryAddress + 2];

                        if (externalSymbolTable.CsList.ContainsKey(CSlabel))
                        {
                            tmpAddress = externalSymbolTable.CsList[CSlabel];
                        }
                        int length = int.Parse(instruction.Substring(7, 2), NumberStyles.HexNumber);
                        if (length == 5)
                        {
                            nibbles = nibbles.Substring(1);
                        }

                        int value = int.Parse(nibbles, NumberStyles.HexNumber);

                        string SymbolLabel = instruction.Substring(10, instruction.Length - 10);
                        SymbolLabel = SymbolLabel.Replace(@" ", "");
                        int SymbolAddress;
                        if (!externalSymbolTable.CsList.ContainsKey(SymbolLabel))
                            SymbolAddress = externalSymbolTable.SymbolList[SymbolLabel][0];
                        else
                            SymbolAddress = externalSymbolTable.CsList[SymbolLabel][0];

                        char sign = instruction[9];
                        if (sign == '+')
                        {
                            value += SymbolAddress;
                        }
                        else if (sign == '-')
                        {
                            value -= SymbolAddress;
                        }

                        nibbles = value.ToString("X");

                        if (length == 5)
                        {
                            string temp = "";
                            temp = temp + memoryMap[memoryAddress][0].ToString();

                            nibbles = padLeft(nibbles, 5);

                            nibbles = temp + nibbles;
                        }
                        else
                        {
                            nibbles = padLeft(nibbles, 6);
                        }
                        memoryMap[memoryAddress] = nibbles.Substring(0, 2);
                        memoryMap[memoryAddress + 1] = nibbles.Substring(2, 2);
                        memoryMap[memoryAddress + 2] = nibbles.Substring(4, 2);
                    }
                }
                CSStartAddress += CSLength;
            }

            return memoryMap;
        }
        /********************************************************************
        *** FUNCTION padLeft                                              ***
        *********************************************************************
        *** DESCRIPTION : pads the string with 0                          ***
        *** INPUT ARGS :                                                  ***
        *** OUTPUT ARGS : string                                          ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        static string padLeft(string str, int i)
        {
            int padCount = i - str.Length;

            if (padCount <= 0)
            {
                return str;
            }

            else
            {
                StringBuilder sb = new StringBuilder();

                for (int j = 0; j < padCount; j++)
                {
                    sb.Append('0');
                }
                sb.Append(str);

                return sb.ToString();
            }
        }
    }
}