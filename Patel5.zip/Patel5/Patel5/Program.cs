﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Linker/Loader***
*** DUE DATE : DEC 5, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the linker loader. ***
********************************************************************/
namespace Patel5
{
    public class Program
    {
        public static int startMemory = int.Parse("01750", System.Globalization.NumberStyles.HexNumber);
        public static int startingCSAddress = startMemory;
        public static int executionAddress = 0;
        public static int length = 0;
        public static Dictionary<int,string> memoryMap = new Dictionary<int,string>();
        /********************************************************************
       *** FUNCTION Main                                                 ***
       *********************************************************************
       *** DESCRIPTION : Displays the symbol,csect, memory map           ***
       *** INPUT ARGS :                                                  ***
       *** OUTPUT ARGS : -                                               ***
       *** IN/OUT ARGS : -                                               ***
       *** RETURN : int                                                  ***
       ********************************************************************/
        public static void Main(string[] args)
        {
            string MemDumpPath = Path.Combine(Directory.GetCurrentDirectory(), "MEMDUMP.DAT");
            
            StreamWriter OFile = new StreamWriter(MemDumpPath);

            List<string[]> programs = new List<string[]>();
            foreach (var item in args)
            {
                programs.Add(File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), item)));
            }

            var symbolTable = Loader.PassOne(programs.ToArray());

            Console.WriteLine("{0,-6} {1,-6} {2,-9} {3,-8} {4,-8} {5,-8}", "CSECT", "SYMBOL", "LDADDR", "CSADDR", "ADDR", "LENGTH");
            
            foreach (var csect in symbolTable.CsList)
            {
                Console.Write("{0,-8} {1,-8} {2,-8}", csect.Key, string.Empty, string.Empty);
                foreach (var value in csect.Value)
                {
                    Console.Write("{0,-6} {1,-6}", value.ToString("X"), string.Empty);
                    Console.Write("{0,-6}", "      ");

                }
                Console.Write("{0,-6}", " ");
                Console.WriteLine();
            }
            foreach (var symbol in symbolTable.SymbolList)
            {
                Console.Write("{0,-7} {1,-7}", string.Empty,symbol.Key);

                foreach (var value in symbol.Value)
                {
                    Console.Write("{0,-10} {1,-8}", value.ToString("X").PadLeft(5,'0'), string.Empty);
                }
                Console.WriteLine();
            }
            int rowCount = (int)Math.Ceiling((double)length / 16);

            Console.WriteLine("Memory Layout : ");
            OFile.WriteLine("Memory Layout : ");

            Console.WriteLine("      0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");
            OFile.WriteLine("      0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");

            var memMap = Loader.PassTwo(programs.ToArray(), symbolTable);
            
            int colCount = 0;
            
            foreach (var item in memMap)
            {
                if (colCount == 0 || colCount > 16)
                {
                    colCount++;
                    Console.Write(item.Key.ToString("X") + " ");
                    OFile.Write(item.Key.ToString("X") + " ");

                    Console.Write(item.Value + " ");
                    OFile.Write(item.Value + " ");
                }

                else if (colCount > 0 && colCount < 16)
                {
                    Console.Write(item.Value + " ");
                    OFile.Write(item.Value + " ");
                    colCount++;

                    if (colCount == 16)
                    {
                        Console.WriteLine("");
                        OFile.WriteLine("");
                        colCount = 0;
                    }
                }

                                              
            }
            Console.WriteLine();
            OFile.WriteLine();

            Console.WriteLine("Excuetion Address: {0}", Program.startMemory.ToString("X"));
            OFile.WriteLine("Execution Address: {0}", Program.startMemory.ToString("X"));

            OFile.Close();
            Console.Read();

            
        }
    }
}
