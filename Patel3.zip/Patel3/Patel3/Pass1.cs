﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass1***
*** DUE DATE : OCT 25, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass1 for the SICXE assembler. ***
********************************************************************/
namespace Patel3
{
    class Operands
    {
        /********************************************************************
        *** FUNCTION <ChkValue> ***
        *********************************************************************
        *** DESCRIPTION : <Function to view literal table>
        *** INPUT ARGS : <value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <numericValue> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private static bool ChkValue(string value, out int numericValue)
        {
            if (int.TryParse(value, out numericValue))
            {
                return true;
            }
            return false;
        }
        /********************************************************************
        *** FUNCTION <Rflag> ***
        *********************************************************************
        *** DESCRIPTION : <checks the rflag>
        *** INPUT ARGS : <rflag> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <boolFlag> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private bool Rflag(string rflag, out bool boolFlag)
        {
            string flag = rflag.ToUpper();
            if (flag == "TRUE" || flag == "1" || flag == "T")
            {
                boolFlag = true;
                return true;
            }
            else if (flag == "FALSE" || flag == "0" || flag == "F")
            {
                boolFlag = false;
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Rflag is invalid.", flag);
                boolFlag = false;
                return false;
            }
        }
        /********************************************************************
        *** FUNCTION <CheckName> ***
        *********************************************************************
        *** DESCRIPTION : <checks the symbol>
        *** INPUT ARGS : <symbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private static bool CheckName(string symbol)
        {
            if (symbol.Length <= 10 && char.IsLetter(symbol[0]))
            {
                symbol = symbol.Substring(1, symbol.Length - 1);

                foreach (var symChar in symbol)
                {
                    if (!char.IsLetterOrDigit(symChar) && !symChar.Equals('_'))
                    {
                        return false;
                    }
                }
            }
            else
                return false;

            return true;
        }
        /********************************************************************
        *** FUNCTION <InsertLiteral> ***
        *********************************************************************
        *** DESCRIPTION : <Insert literal table>
        *** INPUT ARGS : <line> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <numericValue> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private static Literal InsertLiteral(string line)
        {
            var literal = new Literal();
            List<char> parsedValues = new List<char>();
            if (line[2] == '\'')
            {
                try
                {
                    for (int i = 3; line[i] != '\''; i++)
                    {
                        parsedValues.Add(line[i]);
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    throw new FormatException("Error: End quote not found !!!!");
                }
            }
            else
            {
                throw new FormatException("Error:There is no beginning quote !!!");
            }
            if (char.ToUpper(line[1]) == 'C')
            {
                parsedValues.ForEach(value => literal.Value += ((int)value).ToString("X"));

                literal.Length = parsedValues.Count;
                literal.Address = "0";
                literal.Name = line;
            }
            else if (char.ToUpper(line[1]) == 'X')
            {
                parsedValues.ForEach(value =>
                {
                    literal.Value += int.TryParse(value.ToString(), System.Globalization.NumberStyles.HexNumber, null, out int i) ?
                    value : throw new FormatException("Error---Invalid Hex Value");
                });

                if (parsedValues.Count % 2 == 1)
                    throw new FormatException("Error !! Invalid Hex Length");

                literal.Length = parsedValues.Count / 2;
                literal.Address = "0";
                literal.Name = line;
            }
            else
            {
                throw new FormatException("Error: Literal type cannot be found");
            }
            return literal;
        }
        /********************************************************************
        *** FUNCTION <ExprCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Check the expression>
        *** INPUT ARGS : <op, expressionSymbols,symbols> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <value,rflag> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private static void ExprCheck(char op, string[] expressionSymbols, Symbol[] symbols, out int value, out bool rFlag)
        {
            value = 0;
            rFlag = false;

            int rightSideNumber, leftSideNumber;
            bool isRightSideNumber = int.TryParse(expressionSymbols[1], out rightSideNumber),
                    isLeftSideNumber = int.TryParse(expressionSymbols[0], out leftSideNumber);

            if (op == '+')
            {
                if (!isLeftSideNumber && !isRightSideNumber)
                {
                    value = symbols[0].Value + symbols[1].Value;
                    rFlag = RflagEval('+', symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (isLeftSideNumber && !isRightSideNumber)
                {
                    value = leftSideNumber + symbols[0].Value;
                    rFlag = RflagEval('+', false, symbols[0].RFlag);
                }
                else if (!isLeftSideNumber && isRightSideNumber)
                {
                    value = symbols[0].Value + rightSideNumber;
                    rFlag = RflagEval('+', symbols[0].RFlag, false);
                }
                else if (isLeftSideNumber && isRightSideNumber)
                {
                    value = leftSideNumber + rightSideNumber;
                    rFlag = RflagEval('+', false, false);
                }
            }
            else if (op == '-')
            {
                if (!isLeftSideNumber && !isRightSideNumber)
                {
                    value = symbols[0].Value - symbols[1].Value;
                    rFlag = RflagEval('-', symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (isLeftSideNumber && !isRightSideNumber)
                {
                    value = leftSideNumber - symbols[0].Value;
                    rFlag = RflagEval('-', false, symbols[0].RFlag);
                }
                else if (!isLeftSideNumber && isRightSideNumber)
                {
                    value = symbols[0].Value - rightSideNumber;
                    rFlag = RflagEval('-', symbols[0].RFlag, false);
                }
                else if (isLeftSideNumber && isRightSideNumber)
                {
                    value = leftSideNumber - rightSideNumber;
                    rFlag = RflagEval('-', false, false);
                }
            }
        }
        /********************************************************************
        *** FUNCTION <RflagEval> ***
        *********************************************************************
        *** DESCRIPTION : <rflag test for absoulte and relative>
        *** INPUT ARGS : <op,leftFlag,rightFlag> ***
        *** OUTPUT ARGS : <none> ***
        *** IN/OUT ARGS : <none> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private static bool RflagEval(char op, bool leftFlag, bool rightFlag)
        {
            if (op == '+')
            {
                if (!leftFlag && !rightFlag)
                {
                    return false;
                }
                else if (!leftFlag && rightFlag)
                {
                    return true;
                }
                else if (leftFlag && !rightFlag)
                {
                    return true;
                }
                else
                {
                    throw new InvalidOperationException("Error!! It is RELATIVE + RELATIVE");
                }
            }
            else if (op == '-')
            {
                if (!leftFlag && !rightFlag)
                {
                    return false;
                }
                else if (leftFlag && !rightFlag)
                {
                    return true;
                }
                else if (leftFlag && rightFlag)
                {
                    return false;
                }
                else
                {
                    throw new InvalidOperationException("Error: ABSOLUTE - RELATIVE");
                }
            }
            return false;
        }

        /********************************************************************
*** FUNCTION <SetBits()> ***
*********************************************************************
*** DESCRIPTION : <Checks and sets the bits> ***
*** INPUT ARGS : <expression> ***
*** OUTPUT ARGS : <None> ***
*** IN/OUT ARGS : <Nbit,Ibit,Xbit> ***
*** RETURN : <void> ***
********************************************************************/
        private void SetBits(string expression, out bool Nbit, out bool Ibit, out bool Xbit)
        {
            if (expression.Contains(",X") || expression.Contains(",x"))
            {
                Xbit = true;
            }
            else
            {
                Xbit = false;
                if (expression[0] == '@')
                {
                    Nbit = true;
                    Ibit = false;
                    return;

                }
                if (expression[0] == '#')
                {
                    Nbit = false;
                    Ibit = true;
                    return;
                }
            }
            if (char.IsDigit(expression[0]))
            {
                Nbit = false;
                Ibit = true;
                return;
            }
            if (expression[0] == '-')
            {
                Nbit = false;
                Ibit = true;
                return;
            }
            Nbit = true;
            Ibit = true;
        }
        /********************************************************************
        *** FUNCTION <SymbolCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Validate symbol> ***
        *** INPUT ARGS : <expression> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <string[]> ***
        ********************************************************************/
        private static string[] SymbolChk(string expression)
        {
            var symbols = new List<string>();
            if (expression[0] == '@' || expression[0] == '#')
            {
                expression = expression.Substring(1, expression.Length - 1);
            }
            else if (expression.Contains(",X"))
            {
                expression = expression.Remove(expression.IndexOf(','));
            }

            if (expression.Contains('+'))
            {
                symbols = new List<string>(expression.Split('+'));
            }
            else if (expression.Contains('-'))
            {
                symbols = new List<string>(expression.Split('-'));
            }
            else
            {
                symbols.Add(expression);
            }

            return symbols.ToArray();
        }
        /********************************************************************
       *** FUNCTION <Srcfile> ***
       *********************************************************************
       *** DESCRIPTION : <Submain that does operations for the temp file> ***
       *** INPUT ARGS : <file,opcodeTable> ***
       *** OUTPUT ARGS : <None> ***
       *** IN/OUT ARGS : <None> ***
       *** RETURN : <void> ***
       ********************************************************************/
        public void Srcfile(string file, OpcodeTable opcodeTable)
        {
            BST symbolTable = new BST();
            LinkedList literalTable = new LinkedList();
            string[] program = File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), file));
            var sourceFileName = file.Remove(file.IndexOf('.')) + ".tmp";
            bool isComment = false;
            int lineNumber = 0, counter = 0;
            string[] inputLine = ReadLine(program[lineNumber], out isComment);
            string startingAddress, locationCounter;
            string programLength;
            File.Create(sourceFileName).Close();
            while (isComment)
            {
                lineNumber++;
                inputLine = ReadLine(program[lineNumber], out isComment);
            }

            if (inputLine[1] == "START")
            {
                startingAddress = inputLine[2];
                locationCounter = startingAddress;
                symbolTable.Insert(new Symbol()
                {
                    Name = inputLine[0],
                    Value = int.Parse(locationCounter, System.Globalization.NumberStyles.HexNumber),
                    RFlag = true
                });
                WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
                inputLine = ReadLine(program[lineNumber], out isComment);
            }
            else
            {
                startingAddress = "00000";
                locationCounter = startingAddress;
            }

            while (inputLine[1] != "END")
            {
                counter = 0;
                if (!isComment)
                {
                    if (inputLine[0] != string.Empty && inputLine[1] != "EQU")
                    {
                        try
                        {
                            symbolTable.Search(inputLine[2]);
                        }
                        catch (KeyNotFoundException)
                        {
                            string symbol = inputLine[0];
                            if (char.IsLetter(symbol[0]))
                            {


                                symbolTable.Insert(new Symbol()
                                {
                                    Name = inputLine[0],
                                    Value = int.Parse(locationCounter, System.Globalization.NumberStyles.HexNumber),
                                    RFlag = true
                                });
                            }
                            else
                            {
                                Console.WriteLine(string.Format("{0} -> Error: Symbol has an invalid character(s).",symbol));
                            }
                        }
                    }
                    if (opcodeTable.Search(inputLine[1], out Opcode opcode))
                    {
                        counter = opcode.Format;
                    }
                    else if (inputLine[1] == "WORD")
                    {
                        counter = 3;
                    }
                    else if (inputLine[1] == "RESW")
                    {
                        counter = int.Parse(inputLine[2]) * 3;
                    }
                    else if (inputLine[1] == "RESB")
                    {
                        counter = int.Parse(inputLine[2]);
                    }
                    else if (inputLine[1] == "BYTE")
                    {
                        counter = InsertLiteral("=" + inputLine[2]).Length;
                    }
                    else if (inputLine[1] == "EQU")
                    {
                        symbolTable.Insert(SymbolCheck(ref lineNumber, locationCounter, inputLine, symbolTable, sourceFileName));
                        inputLine = ReadLine(program[lineNumber], out isComment);
                        continue;
                    }
                    else
                    {
                        Console.WriteLine(string.Format("{0} ERROR-> Opcode not found.-> Illegal Instruction.",inputLine[2]));
                        lineNumber++;
                        inputLine = ReadLine(program[lineNumber], out isComment);
                        continue;
                    }

                    if (inputLine[2][0] == '=')
                    {
                        literalTable.Appendsymbol(InsertLiteral(inputLine[2]));
                    }
                }
                WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
                locationCounter = IncreamentLocationCounter(locationCounter, counter);

                inputLine = ReadLine(program[lineNumber], out isComment);
            }
            WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
            programLength = ((int.Parse(locationCounter, System.Globalization.NumberStyles.HexNumber) -
                                int.Parse(startingAddress, System.Globalization.NumberStyles.HexNumber)) +
                                DumpLitInEnd(ref literalTable, ref lineNumber, ref locationCounter, sourceFileName)).ToString("X");
            literalTable.View();
            Console.WriteLine("----------------SYMBOL TABLE-------------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------");
            Console.WriteLine("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10}", "LABEL", "VALUE", "RFLAG", "IFLAG", "MFLAG");
            Console.WriteLine("------------------------------------------------------------------------");
            symbolTable.View();
        }
        private static void WriteLineToProgram(ref int lineNumber, string LC, string[] line, string fileName)
        {

            using (StreamWriter writer = File.AppendText(Path.Combine(Directory.GetCurrentDirectory(), fileName)))
            {
                writer.WriteLine("{0, -10} {1, -10} {2, -10} {3, -10} {4, -10}",
                    (++lineNumber).ToString().PadLeft(2, '0'), LC.PadLeft(5, '0'), line[0], line[1], line[2]);
            }
        }
        private static Symbol SymbolCheck(ref int lineNumber, string LC, string[] line, BST symbolTable, string fileName)
        {
            bool rFlag = true;
            int intValue;
            string[] splitLine;
            List<Symbol> symbols = new List<Symbol>();

            if (int.TryParse(line[2], out intValue))
            {
                rFlag = false;
            }
            else if (line[2] == "*")
            {
                rFlag = true;
                intValue = int.Parse(LC, System.Globalization.NumberStyles.HexNumber);
            }
            else if (line[2].Contains("+"))
            {
                splitLine = line[2].Split('+');
                foreach (var symbol in splitLine)
                {
                    symbols.Add(symbolTable.Search(symbol));
                }

                ExprCheck('+', splitLine, symbols.ToArray(), out intValue, out rFlag);
            }
            else if (line[2].Contains("-"))
            {
                splitLine = line[2].Split('-');
                foreach (var symbol in splitLine)
                {
                    symbols.Add(symbolTable.Search(symbol));
                }

                ExprCheck('-', splitLine, symbols.ToArray(), out intValue, out rFlag);
            }
            WriteLineToProgram(ref lineNumber, intValue.ToString("X"), line, fileName);
            return new Symbol
            {
                Name = line[0],
                Value = intValue,
                RFlag = rFlag,
                IFlag = true,
                MFlag = false
            };

        }
        private static string[] ReadLine(string line, out bool isComment)
        {
            isComment = false;
            char[] splitCatergories = { ' ', '\t' };
            var splitLine = line.Split(splitCatergories, StringSplitOptions.RemoveEmptyEntries);
            string[] returnLine = new string[3];

            if (splitLine.Length == 2)
            {
                returnLine[0] = string.Empty;
                returnLine[1] = splitLine[0];
                returnLine[2] = splitLine[1];
            }
            else if (splitLine.Length == 3)
            {
                returnLine = splitLine;
            }
            else if (splitLine[0][0] == '.')
            {
                isComment = true;
            }

            return returnLine;
        }
        private static string IncreamentLocationCounter(string LC, int increment)
        {
            return (int.Parse(LC, System.Globalization.NumberStyles.HexNumber) + increment).ToString("X");
        }
        /********************************************************************
        *** FUNCTION <DumpLitInEnd> ***
        *********************************************************************
        *** DESCRIPTION : <takes literal that shart with * and places them to error>
        *** INPUT ARGS : <literals, lineNumber,LC,fileName> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <none> ***
        ********************************************************************/
        private static int DumpLitInEnd(ref LinkedList literals, ref int lineNumber, ref string LC, string fileName)
        {
            int totalLiteralSize = 0;
            int i = 0;
            foreach (var literal in literals.FindAllsymbols())
            {
                string[] literalLine = { "*", literal.Name, string.Empty };
                WriteLineToProgram(ref lineNumber, LC, literalLine, fileName);
                Literal literalWithAddress = literal;
                literalWithAddress.Address = LC;
                literals.Replacesymbol(literalWithAddress, literal);
                LC = IncreamentLocationCounter(LC, literal.Length);
                totalLiteralSize += literal.Length;
                i++;
            }
            return totalLiteralSize;
        }
    }


}
