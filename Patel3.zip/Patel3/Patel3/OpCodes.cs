﻿using System;
using System.Collections.Generic;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass1***
*** DUE DATE : OCT 25, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass1 for the SICXE assembler. ***
********************************************************************/
namespace Patel3
{
    public struct Opcode
    {
        public string Mnemonic;
        public string Opco;
        public int Format;
    }
    public class OpcodeTable
    {
        private int mnemonicIndex = 0, opcodeIndex = 2, formatIndex = 1;
        private Opcode[] opcodes;
        public Opcode[] Opcodes { get { return opcodes; } }
        /********************************************************************
        *** FUNCTION <OpcodeTable(string[] codes)> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public OpcodeTable(string[] codes)
        {
            OpcodeParser(codes);
        }
        /********************************************************************
        *** FUNCTION <Search(string mnemonicKey,out Opcode opcode)> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        public bool Search(string mnemonicKey, out Opcode opcode)
        {
            int foundIndex = Array.BinarySearch(opcodes, new Opcode { Mnemonic = mnemonicKey }, new OpcodeComparer());
            if (foundIndex >= 0)
            {
                opcode = opcodes[foundIndex];
                return true;
            }
            else
            {
                opcode = new Opcode();
                return false;
            }
        }
        /********************************************************************
        *** FUNCTION <OpcodeTable(string[] lines)> ***
        *********************************************************************
        *** DESCRIPTION : <OpcodeParser for opcodetable> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        private void OpcodeParser(string[] lines)
        {
            List<Opcode> opcodes = new List<Opcode>();
            char[] splitCatagory = { ' ' };
            foreach (var line in lines)
            {
                var splitLine = line.ToUpper().Split(splitCatagory, StringSplitOptions.RemoveEmptyEntries);
                opcodes.Add
                (new Opcode()
                {
                    Mnemonic = splitLine[mnemonicIndex],
                    Format = int.Parse(splitLine[formatIndex]),
                    Opco = splitLine[opcodeIndex]
                });
            }
            opcodes.Sort(new OpcodeComparer());
            this.opcodes = opcodes.ToArray();
        }
    }
    /********************************************************************
    *** FUNCTION <OpcodeComparer:Comparer<Opcode> ***
    *********************************************************************
    *** DESCRIPTION : <OpcodeComparer:Comparer<Opcode> ***
    *** INPUT ARGS : <None> ***
    *** OUTPUT ARGS : <None> ***
    *** IN/OUT ARGS : <None> ***
    *** RETURN : <None> ***
    ********************************************************************/
    public class OpcodeComparer : Comparer<Opcode>
    {
        public override int Compare(Opcode x, Opcode y)
        {
            return string.Compare(x.Mnemonic, y.Mnemonic);
        }
    }
}
