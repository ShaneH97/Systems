﻿using System;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass1***
*** DUE DATE : OCT 25, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass1 for the SICXE assembler. ***
********************************************************************/
namespace Patel3
{
    class Program
    {
        /********************************************************************
        *** FUNCTION <Main()>                                             ***
        *********************************************************************
        *** DESCRIPTION : <Main Driver Program> ***
        *** INPUT ARGS : <args> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        static void Main(string[] args)
        {
            string fileName = args[0];
            while (!File.Exists(Path.Combine(Directory.GetCurrentDirectory(), fileName)))
            {
                Console.Write("Error-> SICXE file does not exist.Please enter a valid file name/file path: ");
                fileName = Console.ReadLine();
            }
            Console.Clear();
            OpcodeTable opcodes = new OpcodeTable(File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), "OPCODES.DAT")));
            Operands read_file = new Operands();
            read_file.Srcfile(fileName, opcodes);
            Console.Read();
        }
    }
}
