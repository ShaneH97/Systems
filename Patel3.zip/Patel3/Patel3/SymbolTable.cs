﻿using System;
using System.Collections.Generic;
/********************************************************************
* NAME : Meet Patel                                             *
* CLASS : CSC 354                                               *
* ASSIGNMENT : SYMBOL TABLE                                     *
* DUE DATE : 9/13/2018                                          *
* INSTRUCTOR : Mr. Werpy                                        *
*******************************************************************
* DESCRIPTION : This program reads from the file that contains  *
* information about the symbol, values and the flags (rflag,    *
* iflag, mflag) check for the validation                        *
********************************************************************/
namespace Patel3
{
    public struct Symbol
    {
        public string Name;
        public int Value;
        public bool RFlag, IFlag, MFlag;
    }
    public class BSTsymbol
    {
        public Symbol Element;
        public BSTsymbol Left, Right;
    }
    public class BST
    {
        public BSTsymbol myTree;
        /********************************************************************
        *** FUNCTION <BST()> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public BST()
        {
            myTree = null;
        }
        /********************************************************************
        *** FUNCTION <Insert()> ***
        *********************************************************************
        *** DESCRIPTION : <Insert the Symbol> ***
        *** INPUT ARGS : <symbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void Insert(Symbol symbol)
        {
            symbol.Name = symbol.Name.Length > 5 ? symbol.Name.Remove(5) : symbol.Name;
            Insert(symbol, ref myTree);
        }
        /********************************************************************
        *** FUNCTION <Insert()> ***
        *********************************************************************
        *** DESCRIPTION : <Insert into BST Search Tree> ***
        *** INPUT ARGS : <symbol, myTree> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void Insert(Symbol symbol, ref BSTsymbol myTree)
        {
            if (myTree == null)
            {
                myTree = new BSTsymbol()
                {
                    Element = symbol,
                    Left = null,
                    Right = null
                };
            }
            else if (string.Compare(symbol.Name, myTree.Element.Name) < 0)
            {
                Insert(symbol, ref myTree.Left);
                myTree.Element.MFlag = false;

            }
            else if (string.Compare(symbol.Name, myTree.Element.Name) > 0)
            {
                Insert(symbol, ref myTree.Right);
                myTree.Element.MFlag = false;
            }
            else
            {
                myTree.Element.MFlag = true;
            }
        }
        /********************************************************************
        *** FUNCTION <Search()> ***
        *********************************************************************
        *** DESCRIPTION : <Search the Symbol> ***
        *** INPUT ARGS : <symbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <symbol> ***
        ********************************************************************/
        public Symbol Search(Symbol symbol)
        {
            symbol.Name = symbol.Name.Length > 5 ? symbol.Name.Remove(5) : symbol.Name;
            return Search(symbol, myTree).Element;
        }
        /********************************************************************
        *** FUNCTION <Search()> ***
        *********************************************************************
        *** DESCRIPTION : <Search into BST Search Tree> ***
        *** INPUT ARGS : <root, value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <BSTsymbol> ***
        ********************************************************************/
        public Symbol Search(string symbol)
        {
            var returnSymbol = Search(new Symbol() { Name = symbol = symbol.Length > 5 ? symbol.Remove(5) : symbol }, myTree);
            if (returnSymbol == null)
                throw new KeyNotFoundException(symbol + ": Symbol not found");
            else
                return returnSymbol.Element;
        }
        /********************************************************************
        *** FUNCTION <Search()> ***
        *********************************************************************
        *** DESCRIPTION : <Search into BST Search Tree> ***
        *** INPUT ARGS : <root, myTree> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <BSTsymbol> ***
        ********************************************************************/
        private BSTsymbol Search(Symbol symbol, BSTsymbol myTree)
        {
            if (myTree == null)
            {
                return null;
            }
            else if (string.Compare(symbol.Name, myTree.Element.Name) < 0)
            {
                return Search(symbol, myTree.Left);
            }
            else if (string.Compare(symbol.Name, myTree.Element.Name) > 0)
            {
                return Search(symbol, myTree.Right);
            }
            else
            {
                return myTree;
            }
        }
        /********************************************************************
        *** FUNCTION <View()> ***
        *********************************************************************
        *** DESCRIPTION : <View the tree> ***
        *** INPUT ARGS : <mytree> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void View()
        {
            PreView(myTree);
        }
        /********************************************************************
        *** FUNCTION <PreView()> ***
        *********************************************************************
        *** DESCRIPTION : <View the tree> ***
        *** INPUT ARGS : <mytree> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void PreView(BSTsymbol myTree)
        {
            if (myTree != null)
            {
                myTree.Element.IFlag = true;
                var symbol = myTree.Element;
                if (myTree.Left != null)
                    PreView(myTree.Left);
                Console.WriteLine("{0, -10} {1, -10} {2, -15} {3, -10} {4, -10}", myTree.Element.Name, myTree.Element.Value.ToString("X"), myTree.Element.RFlag, myTree.Element.IFlag, myTree.Element.MFlag);
                if (myTree.Right != null)
                    PreView(myTree.Right);
            }
        }
    }
}