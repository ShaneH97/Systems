﻿using System;
using System.Collections.Generic;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass1***
*** DUE DATE : OCT 25, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass1 for the SICXE assembler. ***
********************************************************************/
namespace Patel3
{
    public struct Literal
    {
        public string Name;
        public string Value;
        public int Length;
        public string Address;
    }

    class Listsymbol
    {
        public Literal literal;
        public Listsymbol Next;
    }

    class LinkedList
    {
        private Listsymbol head;

        /********************************************************************
         *** FUNCTION <LiteralList> ***
         *********************************************************************
         *** DESCRIPTION : <Constructor> ***
         *** INPUT ARGS : <None> ***
         *** OUTPUT ARGS : <None> ***
         *** IN/OUT ARGS : <None> ***
         *** RETURN : <None> ***
         ********************************************************************/
        public LinkedList()
        {
            head = null;
        }
        /********************************************************************
        *** FUNCTION <Appendsymbol> ***
        *********************************************************************
        *** DESCRIPTION : <The use of linked list to append/add symbol>
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void Appendsymbol(Literal literal)
        {
            Listsymbol newsymbol = new Listsymbol()
            {
                literal = literal,
                Next = null
            };
            Listsymbol symbolptr;
            if (head == null)
            {
                head = newsymbol;
            }
            else
            {
                symbolptr = head;
                while (symbolptr.Next != null)
                {
                    symbolptr = symbolptr.Next;
                }
                symbolptr.Next = newsymbol;
            }
        }
        /********************************************************************
        *** FUNCTION <FindAllsymbols> ***
        *********************************************************************
        *** DESCRIPTION : <The use of linked list to find if name exists or not>
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <literal[]> ***
        ********************************************************************/
        public Literal[] FindAllsymbols()
        {
            List<Literal> symbols = new List<Literal>();
            Listsymbol symbolptr = head;
            while (symbolptr != null)
            {
                symbols.Add(symbolptr.literal);
                symbolptr = symbolptr.Next;
            }
            return symbols.ToArray();
        }
        /********************************************************************
        *** FUNCTION <ReplaceSymbol> ***
        *********************************************************************
        *** DESCRIPTION : <Search and replace the symbol>
        *** INPUT ARGS : <newsymbol,previoussymbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void Replacesymbol(Literal newsymbol, Literal previoussymbol)
        {
            Listsymbol symbolptr = head;

            while (symbolptr != null)
            {
                if (previoussymbol.Name == symbolptr.literal.Name)
                {
                    symbolptr.literal = newsymbol;
                }

                symbolptr = symbolptr.Next;
            }
        }
        /********************************************************************
        *** FUNCTION <View> ***
        *********************************************************************
        *** DESCRIPTION : <Function to view literal table>
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void View()
        {
            Console.WriteLine("********************LITERAL TABLE**************************");
            Console.WriteLine("{0,-12} {1,-18} {2,-10} {3,-10}", "Name", "Value", "Length", "Address");
            Console.WriteLine("***********************************************************");
            Listsymbol symbolptr = head;
            while (symbolptr != null)
            {
                Console.WriteLine("{0,-12} {1,-18} {2,-10} {3,-10}", symbolptr.literal.Name, symbolptr.literal.Value, symbolptr.literal.Length, symbolptr.literal.Address);
                symbolptr = symbolptr.Next;
            }
            Console.WriteLine("***********************************************************");
        }
    }
}
