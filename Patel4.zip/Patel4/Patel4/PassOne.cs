﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler. ***
********************************************************************/
namespace Patel4
{
    public struct Opcode
    {
        public string Mnemonic;
        public string Opco;
        public int Format;

    }
    public class OpcodeCmpr : Comparer<Opcode>
    {
        /********************************************************************
        *** FUNCTION Compare(Opcode x, Opcode y)
        *********************************************************************
        *** DESCRIPTION : This is the asbstract function derived from the ***
        *** Comparer class that is used to compare for sorting the opcode ***
        *** array                                                         ***
        *** INPUT ARGS : x, y                                             ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        public override int Compare(Opcode x, Opcode y)
        {
            return string.Compare(x.Mnemonic, y.Mnemonic);
        }
    }
    public struct Literal
    {
        public string Name;
        public string Value;
        public int Length;
        public string Address;

        public override string ToString()
        {
            return string.Format("{0,-12} {1,-18} {2,-10} {3,-10}", Name, Value, Length, Address);
        }
    }
    public struct Symbol
    {
        public string Name;
        public int Value;
        public bool RFlag;
        public bool IFlag;
        public bool MFlag;

        public override string ToString()
        {
            return string.Format("{0, -10} {1, -10} {2, -15} {3, -10} {4, -10}", Name, Value.ToString("X"), RFlag, IFlag, MFlag);
        }
    }
    public class SymbolComparer : IComparer<Symbol>
    {
        public int Compare(Symbol x, Symbol y)
        {
            return string.Compare(x.Name, y.Name);
        }
    }
    public class PassOne
    {
        private int mnemonicIndex = 0, opcodeIndex = 1, formatIndex = 2;

        private Opcode[] opcodes;
        private BST<Symbol> symbolTable;
        private LinkedList<Literal> literalTable;
        private string programLength;
        private string startingAddress;
        private string programName;

        public Opcode[] Opcodes { get { return opcodes; } }
        public BST<Symbol> SymbolTable { get { return symbolTable; } }
        public LinkedList<Literal> LiteralTable { get { return literalTable; } }
        public string ProgramLength { get { return programLength; } }
        public string StartingAddress { get { return startingAddress; } }
        public string ProgramName { get { return programName; } }
        /********************************************************************
        *** FUNCTION PassOne                                              ***
        *********************************************************************
        *** DESCRIPTION : This is the default constructor for OpTable class**
        *** INPUT ARGS : codes                                            ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        public PassOne(string[] codes)
        {
            symbolTable = new BST<Symbol>(new SymbolComparer());
            literalTable = new LinkedList<Literal>();
            OpcodeParser(codes);
        }
        /********************************************************************
        *** FUNCTION SrchOpable                                           ***
        *********************************************************************
        *** DESCRIPTION : This is the public function searches the opcodes***
        *** to return whether it found the opcode in the opcode array or not*
        *** INPUT ARGS : mnemonic                                         ***
        *** OUTPUT ARGS : opcode                                          ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : bool                                                 ***
        ********************************************************************/
        public bool SrchOpTable(string mnemonic, out Opcode opcode)
        {
            int foundIndex;
            if (mnemonic[0] == '+')
            {
                mnemonic = mnemonic.Substring(1, mnemonic.Length - 1);
                foundIndex = Array.BinarySearch(opcodes, new Opcode { Mnemonic = mnemonic }, new OpcodeCmpr());
                if (foundIndex >= 0)
                {
                    opcode = opcodes[foundIndex];
                    opcode.Format = 4;
                    return true;
                }
                else
                {
                    opcode = new Opcode();
                    return false;
                }
            }
            else
            {
                foundIndex = Array.BinarySearch(opcodes, new Opcode { Mnemonic = mnemonic }, new OpcodeCmpr());

                if (foundIndex >= 0)
                {
                    opcode = opcodes[foundIndex];
                    return true;
                }
                else
                {
                    opcode = new Opcode();
                    return false;
                }
            }
        }
        /*********************************************************************
        *** FUNCTION OpcodeParser                                          ***
        **********************************************************************
        *** DESCRIPTION : This is the private function that parses the opcode* 
        *** for use in looking up the opcode to get format for pass 1      ***
        *** operation                                                      ***
        *** INPUT ARGS : lines                                             ***
        *** OUTPUT ARGS : -                                                ***
        *** IN/OUT ARGS : -                                                ***
        *** RETURN : void                                                  ***
        **********************************************************************/
        private void OpcodeParser(string[] lines)
        {
            List<Opcode> opcodes = new List<Opcode>();
            char[] StrSeparator = { ' ', '\t' };

            foreach (var line in lines)
            {
                int i = 0;
                var SplitOneLine = line.ToUpper().Split(StrSeparator, StringSplitOptions.RemoveEmptyEntries);
                for (i = 0; i < SplitOneLine.Length; i++)
                {
                    if (i == 0)
                    {
                        mnemonicIndex = i;
                    }
                    if (i == 1)
                    {
                        formatIndex = i;
                    }
                    if (i == 2)
                    {
                        opcodeIndex = i;
                    }
                }
                opcodes.Add
                    (new Opcode()
                    {
                        Mnemonic = SplitOneLine[mnemonicIndex],
                        Format = int.Parse(SplitOneLine[formatIndex]),
                        Opco = SplitOneLine[opcodeIndex]
                    });
            }
            opcodes.Sort(new OpcodeCmpr());
            this.opcodes = opcodes.ToArray();
        }
        /********************************************************************** 
        **** FUNCTION : WriteLineToProgram(ref int lineNumber, string LC, string[] line, string fileName)
        **********************************************************************  
        **** DESCRIPTION : This function writes the source file lines to the 
        **** intermediate file
        **** INPUT ARGS : LC, line, filename
        **** OUTPUT ARGS : NONE
        **** IN/OUT ARGS : lineNumber  
        **** RETURN : void
        *********************************************************************/
        private static void WriteLineToProgram(ref int lineNumber, string LC, string[] line, string fileName)
        {

            using (StreamWriter writer = File.AppendText(Path.Combine(Directory.GetCurrentDirectory(), fileName)))
            {
                writer.WriteLine("{0, -10} {1, -10} {2, -10} {3, -10} {4, -10}",
                    (++lineNumber).ToString().PadLeft(2, '0'), LC.PadLeft(5, '0'), line[0], line[1], line[2]);
            }
        }
        /********************************************************************** 
        **** FUNCTION : ReadLine(string line, out bool isComment)
        **********************************************************************  
        **** DESCRIPTION : This function reads all lines and splits it.
        **** INPUT ARGS : line, isComment
        **** OUTPUT ARGS : NONE
        **** IN/OUT ARGS : NONE
        **** RETURN : string[] 
        *********************************************************************/
        private static string[] ReadLine(string line, out bool isComment)
        {
            isComment = false;
            char[] splitCatergories = { ' ', '\t' };
            var splitLine = line.Split(splitCatergories, StringSplitOptions.RemoveEmptyEntries);
            string[] returnLine = new string[3];
            if (splitLine[0][0] == '.')
            {
                isComment = true;
                return returnLine;
            }
            if (splitLine.Length >= 3)
            {
                if (splitLine[2][0] == '.')
                {
                    returnLine[0] = string.Empty;
                    returnLine[1] = splitLine[0];
                    returnLine[2] = splitLine[1];
                }
                else
                {
                    returnLine[0] = splitLine[0];
                    returnLine[1] = splitLine[1];
                    returnLine[2] = splitLine[2];
                }
            }
            else if (splitLine.Length == 2)
            {
                returnLine[0] = string.Empty;
                returnLine[1] = splitLine[0];
                returnLine[2] = splitLine[1];
            }
            return returnLine;
        }

        /********************************************************************** 
        **** FUNCTION : IncreamentLocationCounter(string LC, int increment)
        **********************************************************************  
        **** DESCRIPTION : This function increments the location counter while reading
        **** through the source file
        **** INPUT ARGS : LC, increment
        **** OUTPUT ARGS : -
        **** IN/OUT ARGS : -  
        **** RETURN : string
        *********************************************************************/
        private static string IncreamentLocationCounter(string LC, int increment)
        {
            return (int.Parse(LC, System.Globalization.NumberStyles.HexNumber) + increment).ToString("X");
        }
        /********************************************************************** 
        **** FUNCTION : DumpLitInEnd
        **********************************************************************  
        **** DESCRIPTION : This function dums the literal in the end of the intermediate
        **** file
        **** INPUT ARGS : filename
        **** OUTPUT ARGS : -
        **** IN/OUT ARGS : literals, lineNumber, LC  
        **** RETURN : int
        *********************************************************************/
        private static int DumpLitInEnd(ref LinkedList<Literal> literals, ref int lineNumber, ref string LC, string fileName)
        {
            int totalLiteralSize = 0;
            int i = 0;
            foreach (var literal in literals)
            {
                string[] literalLine = { "*", literal.Name, string.Empty };
                WriteLineToProgram(ref lineNumber, LC, literalLine, fileName);
                Literal literalWithAddress = literal;
                literalWithAddress.Address = LC;
                literals.ReplaceNode(literalWithAddress, literal);
                LC = IncreamentLocationCounter(LC, literal.Length);
                totalLiteralSize += literal.Length;
                i++;
            }
            return totalLiteralSize;
        }
        /********************************************************************* 
        *** FUNCTION : DefineSymbol(ref int lineNumber, string LC, string[] line, string fileName)
        **********************************************************************  
        *** DESCRIPTION : define the symbol
        *** INPUT ARGS : linenumber, lc, line, filename                    ***
        *** OUTPUT ARGS : -                                                ***
        *** IN/OUT ARGS : -                                                ***
        *** RETURN :                                                       ***  
        **********************************************************************/
        private void DefineSymbol(ref int lineNumber, string LC, string[] line, string fileName)
        {
            bool rFlag = true;
            int intValue;
            string[] splitLine;
            List<Symbol> symbols = new List<Symbol>();

            if (int.TryParse(line[2], out intValue))
            {
                rFlag = false;
            }
            else if (line[2] == "*")
            {
                rFlag = true;
                intValue = int.Parse(LC, System.Globalization.NumberStyles.HexNumber);
            }
            else if (line[2].Contains("+"))
            {
                splitLine = line[2].Split('+');
                foreach (var symbol in splitLine)
                {
                    if (SearchSymbol(symbol, out Symbol found))
                    {
                        symbols.Add(found);
                    }
                }

                Expressions.ChkExpr('+', splitLine, symbols.ToArray(), out intValue, out rFlag);
            }
            else if (line[2].Contains("-"))
            {
                splitLine = line[2].Split('-');
                foreach (var symbol in splitLine)
                {
                    if (SearchSymbol(symbol, out Symbol found))
                    {
                        symbols.Add(found);
                    }
                }

                Expressions.ChkExpr('-', splitLine, symbols.ToArray(), out intValue, out rFlag);
            }
            WriteLineToProgram(ref lineNumber, intValue.ToString("X"), line, fileName);
            InsertSymbol(line[0], intValue.ToString("X"), rFlag, true, false);

        }
        /********************************************************************
        *** FUNCTION InsertSymbol(string name, string value, bool rFlag, bool iFlag, bool mFlag)
        *********************************************************************
        *** DESCRIPTION : insert the symbol                               ***
        *** INPUT ARGS : name,value,rflag,iflag,mflag                    ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : -                                                    ***
        ********************************************************************/
        public void InsertSymbol(string name, string value, bool rFlag, bool iFlag, bool mFlag)
        {
            symbolTable.Insertnode(new Symbol
            {
                Name = name.Length > 5 ? name.Remove(5) : name,
                Value = int.Parse(value, System.Globalization.NumberStyles.HexNumber),
                RFlag = rFlag,
                IFlag = iFlag,
                MFlag = mFlag
            });
        }
        /********************************************************************
        *** FUNCTION SearchSymbol(string name, out Symbol symbol)
        *********************************************************************
        *** DESCRIPTION : Search symbol and return it                     ***
        *** INPUT ARGS : name,symbol                                      ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : bool                                                 ***
        ********************************************************************/
        public bool SearchSymbol(string name, out Symbol symbol)
        {
            string parsedSymbol = Expressions.ParseSymbol(name);
            return symbolTable.SearchNode(new Symbol { Name = parsedSymbol.Length > 5 ? parsedSymbol.Remove(5) : parsedSymbol }, out symbol);
        }
        /********************************************************************
        *** FUNCTION Start_PassOne                                       ***
        *********************************************************************
        *** DESCRIPTION : Start Pass One                                  ***
        *** INPUT ARGS : file                                             ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : -                                                  ***
        ********************************************************************/
        public void Start_PassOne(string file)
        {
            string[] program = File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), file));
            var sourceFileName = file.Remove(file.IndexOf('.')) + ".tmp";
            bool isComment = false, checkedFormat1 = false;
            int lineNumber = 0, counter = 0;
            string[] inputLine = ReadLine(program[lineNumber], out isComment);
            string locationCounter;
            File.Create(sourceFileName).Close();
            while (isComment)
            {
                lineNumber++;
                inputLine = ReadLine(program[lineNumber], out isComment);
            }
            if (inputLine[1] == "START")
            {
                startingAddress = inputLine[2];
                locationCounter = startingAddress;
                programName = inputLine[0];
                InsertSymbol(inputLine[0], locationCounter, true, true, false);
                WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
                inputLine = ReadLine(program[lineNumber], out isComment);
            }
            else
            {
                startingAddress = "00000";
                locationCounter = startingAddress;
                programName = string.Empty;
            }
            while (inputLine[1] != "END")
            {
                counter = 0;
                if (!isComment)
                {
                    if (inputLine[0] != string.Empty && inputLine[1] != "EQU")
                    {
                        if (!SearchSymbol(inputLine[0], out Symbol found))
                        {
                            if (char.IsLetter(inputLine[0][0]))
                            {
                                InsertSymbol(inputLine[0], locationCounter, true, true, false);
                            }
                            else
                            {
                                Console.WriteLine("Error!.. Invalid Symbol!");
                            }
                        }
                    }
                    if (SrchOpTable(inputLine[1], out Opcode opcode))
                    {
                        string mnemonic = inputLine[1];
                        if (opcode.Format == 4)
                        {
                            counter = 4;
                        }
                        else
                        {
                            counter = opcode.Format;
                        }
                    }
                    else if (inputLine[1] == "BASE" || inputLine[1] == "EXTREF" || inputLine[1] == "EXTDEF")
                    {
                        inputLine = ReadLine(program[lineNumber], out isComment);
                    }
                    else if (inputLine[1] == "WORD")
                    {
                        counter = 3;
                    }
                    else if (inputLine[1] == "RESW")
                    {
                        counter = int.Parse(inputLine[2]) * 3;
                    }
                    else if (inputLine[1] == "RESB")
                    {
                        counter = int.Parse(inputLine[2]);
                    }
                    else if (inputLine[1] == "BYTE")
                    {
                        counter = Expressions.ParseConstant(inputLine[2]).Length;
                    }
                    else if (inputLine[1] == "EQU")
                    {
                        DefineSymbol(ref lineNumber, locationCounter, inputLine, sourceFileName);
                        inputLine = ReadLine(program[lineNumber], out isComment);
                        continue;
                    }
                    else
                    {
                        if (!checkedFormat1)
                        {
                            inputLine[0] = inputLine[1];
                            inputLine[1] = inputLine[2];
                            inputLine[2] = string.Empty;
                        }
                        else
                        {
                            inputLine = ReadLine(program[lineNumber], out isComment);
                            checkedFormat1 = false;
                        }
                        continue;
                    }
                    if (inputLine[2].Length != 0 ? inputLine[2][0] == '=' : false)
                    {
                        var constant = Expressions.ParseConstant(inputLine[2].Substring(1, inputLine[2].Length - 1));
                        constant.Name = "=" + constant.Name;
                        literalTable.AppendNode(constant);
                    }
                }
                else
                {
                    lineNumber++;
                    inputLine = ReadLine(program[lineNumber], out isComment);
                    continue;
                }
                WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
                locationCounter = IncreamentLocationCounter(locationCounter, counter);
                inputLine = ReadLine(program[lineNumber], out isComment);
            }
            WriteLineToProgram(ref lineNumber, locationCounter, inputLine, sourceFileName);
            programLength = ((int.Parse(locationCounter, System.Globalization.NumberStyles.HexNumber) -
                                int.Parse(startingAddress, System.Globalization.NumberStyles.HexNumber)) +
                                DumpLitInEnd(ref literalTable, ref lineNumber, ref locationCounter, sourceFileName)).ToString("X");
            PassTwo.Start_PassTwo(sourceFileName, this);
            Console.WriteLine("Intermediate File");
            Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", "Line No", "LC", "Label", "Operation", "Operand");
            foreach (var intermediateLine in File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), sourceFileName)))
            {
                Console.WriteLine(intermediateLine);
            }
            Console.WriteLine();
            Console.WriteLine("Symbol Table");
            Console.WriteLine("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10}", "Label", "Value", "RFlag", "IFlag", "MFlag");
            symbolTable.InView();
            literalTable.View();
        }
    }
}