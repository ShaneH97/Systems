﻿using System;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler.
********************************************************************/
namespace Patel4
{
    class Program
    {
        /********************************************************************
        *** FUNCTION <Main()>                                             ***
        *********************************************************************
        *** DESCRIPTION : <Main Driver Program> ***
        *** INPUT ARGS : <args> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        static void Main(string[] args)
        {

            string fileName;
            if (args.Length != 0)
            {
                fileName = args[0];
            }
            else
            {
                fileName = string.Empty;
            }
            while (!File.Exists(Path.Combine(Directory.GetCurrentDirectory(), fileName)))
            {
                Console.Write("Error-> SICXE file does not exist.Please enter a valid file name/file path: ");
                fileName = Console.ReadLine();
            }
            Console.Clear();
            PassOne opcodes = new PassOne(File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), "OPSCODES.DAT")));
            opcodes.Start_PassOne(fileName);
            Console.Read();
        }
    }
}