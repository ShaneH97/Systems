﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler. ***
********************************************************************/
namespace Patel4
{
    static class Expressions
    {
        /**************************************************************************
        *** FUNCTION : ParseConstant                                                  
        ***************************************************************************
        *** DESCRIPTION : ParseConstant                                         ***
        *** INPUT ARGS : Line                                                  *** 
        *** OUTPUT ARGS : -                                                     ***
        *** IN/OUT ARGS : -                                                     ***
        *** RETURN : static bool                                                ***
        **************************************************************************/
        public static Literal ParseConstant(string line)
        {
            var literal = new Literal();
            List<char> parse_vals = new List<char>();

            if (line[1] == '\'')
            {
                try
                {
                    for (int i = 2; line[i] != '\''; i++)
                    {
                        parse_vals.Add(line[i]);
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    throw new FormatException("Error: End quote not found !!!!");
                }
            }
            else
            {
                throw new FormatException("Error:There is no beginning quote !!!");
            }

            if (char.ToUpper(line[0]) == 'C')
            {
                parse_vals.ForEach(value => literal.Value += ((int)value).ToString("X"));

                literal.Length = parse_vals.Count;
                literal.Address = "0";
                literal.Name = line;
            }
            else if (char.ToUpper(line[0]) == 'X')
            {
                parse_vals.ForEach(value =>
                {
                    literal.Value += int.TryParse(value.ToString(), System.Globalization.NumberStyles.HexNumber, null, out int i) ?
                    value : throw new FormatException("Error---Invalid Hex Value");
                });

                if (parse_vals.Count % 2 == 1)
                    throw new FormatException("Error !! Invalid Hex Length");

                literal.Length = parse_vals.Count / 2;
                literal.Address = "0";
                literal.Name = line;
            }
            else
            {
                throw new FormatException("Error: Literal type cannot be found");
            }

            return literal;
        }
        /**************************************************************************
        *** FUNCTION : ChkVal                                                   ***
        ***************************************************************************
        *** DESCRIPTION : This is private function checks the value in the symbol**
        *** file checks to see if value is numeric or not                       ***
        *** INPUT ARGS : value                                                  *** 
        *** OUTPUT ARGS : numericValue                                          ***
        *** IN/OUT ARGS : -                                                     ***
        *** RETURN : static bool                                                ***
        **************************************************************************/
        public static bool ChkVal(string value, out int numericValue)
        {
            if (int.TryParse(value, out numericValue))
            {
                return true;
            }
            return false;
        }
        /****************************************************************************
        *** FUNCTION : RFlagChk                                                   ***
        *****************************************************************************
        *** DESCRIPTION : This is functions checks the Rflag validity in the symbol**
        *** table                                                                  **
        *** INPUT ARGS : rflag                                                    ***
        *** OUTPUT ARGS : boolFlag                                                ***
        *** IN/OUT ARGS : -                                                       ***
        *** RETURN : static bool                                                  ***
        ****************************************************************************/
        public static bool RFlagChk(string rflag, out bool boolFlag)
        {
            string flag = rflag.ToUpper();
            if (flag == "TRUE" || flag == "1" || flag == "T")
            {
                boolFlag = true;
                return true;
            }
            else if (flag == "FALSE" || flag == "0" || flag == "F")
            {
                boolFlag = false;
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Rflag is invalid.", flag);
                boolFlag = false;
                return false;
            }
        }
        /********************************************************************
        *** FUNCTION : ChkName
        *********************************************************************
        *** DESCRIPTION : This function checks if the symbol is valid
        *** INPUT ARGS : symbol
        *** OUTPUT ARGS : -
        *** IN/OUT ARGS : -
        *** RETURN : static bool
        *********************************************************************/
        public static bool ChkName(string symbol)
        {
            if (symbol.Length <= 10 && char.IsLetter(symbol[0]))
            {
                symbol = symbol.Substring(1, symbol.Length - 1);

                foreach (var symChar in symbol)
                {
                    if (!char.IsLetterOrDigit(symChar) && !symChar.Equals('_'))
                    {
                        return false;
                    }
                }
            }
            else
                return false;

            return true;
        }

        /********************************************************************
        *** FUNCTION :  ChkExpr
        *********************************************************************
        *** DESCRIPTION : This is functions that evaluate exp file.Test the 
        ***				values in the files and add if numeric.
        *** INPUT ARGS : string FILEname, Binary NewTable
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : static void
        ********************************************************************/
        public static void ChkExpr(char op, string[] expressionSymbols, Symbol[] symbols, out int value, out bool rFlag)
        {
            value = 0;
            rFlag = false;

            int rightSideNumber, leftSideNumber;
            bool isRightSideNumber = int.TryParse(expressionSymbols[1], out rightSideNumber),
                    isLeftSideNumber = int.TryParse(expressionSymbols[0], out leftSideNumber);

            if (op == '+')
            {
                if (!isLeftSideNumber && !isRightSideNumber)
                {
                    value = symbols[0].Value + symbols[1].Value;
                    rFlag = Expressions.EvaluateRFlag('+', symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (isLeftSideNumber && !isRightSideNumber)
                {
                    value = leftSideNumber + symbols[0].Value;
                    rFlag = Expressions.EvaluateRFlag('+', false, symbols[0].RFlag);
                }
                else if (!isLeftSideNumber && isRightSideNumber)
                {
                    value = symbols[0].Value + rightSideNumber;
                    rFlag = Expressions.EvaluateRFlag('+', symbols[0].RFlag, false);
                }
                else if (isLeftSideNumber && isRightSideNumber)
                {
                    value = leftSideNumber + rightSideNumber;
                    rFlag = Expressions.EvaluateRFlag('+', false, false);
                }
            }
            else if (op == '-')
            {
                if (!isLeftSideNumber && !isRightSideNumber)
                {
                    value = symbols[0].Value - symbols[1].Value;
                    rFlag = Expressions.EvaluateRFlag('-', symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (isLeftSideNumber && !isRightSideNumber)
                {
                    value = leftSideNumber - symbols[0].Value;
                    rFlag = Expressions.EvaluateRFlag('-', false, symbols[0].RFlag);
                }
                else if (!isLeftSideNumber && isRightSideNumber)
                {
                    value = symbols[0].Value - rightSideNumber;
                    rFlag = Expressions.EvaluateRFlag('-', symbols[0].RFlag, false);
                }
                else if (isLeftSideNumber && isRightSideNumber)
                {
                    value = leftSideNumber - rightSideNumber;
                    rFlag = Expressions.EvaluateRFlag('-', false, false);
                }
            }
        }


        /********************************************************************** 
         *** FUNCTION : EvaluateRFlag                                       ***
         **********************************************************************  
         *** DESCRIPTION : This function evaluate the overall Rflag for the ***
         *** expressions in the source program                              ***
         *** INPUT ARGS : op, leftRFlag, rightRFlag                         ***
         *** OUTPUT ARGS : -                                                ***
         *** IN/OUT ARGS : -                                                ***
         *** RETURN : bool                                                  *** 
         *********************************************************************/
        public static bool EvaluateRFlag(char op, bool leftRFlag, bool rightRFlag)
        {
            int result = -1;
            if (op == '+')
            {
                result = (leftRFlag ? 1 : 0) + (rightRFlag ? 1 : 0);
            }
            else if (op == '-')
            {
                result = (leftRFlag ? 1 : 0) - (rightRFlag ? 1 : 0);
            }

            if (result > 1)
                throw new InvalidOperationException("Error: RELATIVE + RELATIVE");
            else if (result < 0)
                throw new InvalidOperationException("Error: ABSOLUTE - RELATIVE");

            return result == 1 ? true : false;
        }

        /**********************************************************************************
        *** FUNCTION : SetBits                                                          ***
        ***********************************************************************************
        *** DESCRIPTION : This is function validates expressions and sets the bits N,I,X **
        *** INPUT ARGS : expression                                                     ***
        *** OUTPUT ARGS : Nbit, Ibit, Xbit                                              ***
        *** IN/OUT ARGS : -                                                             ***
        *** RETURN : void                                                               ***
        ***********************************************************************************/
        public static byte[] SetBits(string expression)
        {
            byte[] objectInstruction = { 3, 0 };
            expression = expression.ToUpper().Trim(); ;

            if (expression.Contains(",X"))
            {
                objectInstruction[1] |= 0b1000;
            }
            else
            {
                if (expression[0] == '@')
                {
                    objectInstruction[0] &= 0b0010;

                }
                if (expression[0] == '#' || char.IsDigit(expression[0]))
                {
                    objectInstruction[0] &= 0b0001;
                }
            }

            return objectInstruction;
        }

        public static string ParseSymbol(string expression)
        {
            if (expression.Contains(",X"))
            {
                expression = expression.Remove(expression.IndexOf(",X"));
            }

            if (expression[0] == '@' || expression[0] == '#')
            {
                expression = expression.Substring(1, expression.Length - 1);
            }

            return expression;
        }

        /********************************************************************** 
        **** FUNCTION : SymbolParse
        **********************************************************************  
        **** DESCRIPTION : This function 
        **** INPUT ARGS : string expression
        **** OUTPUT ARGS : NONE
        **** IN/OUT ARGS : NONE  
        **** RETURN : symbols.ToArray()
        *********************************************************************/
        public static string[] ParseSymbols(string expression)
        {
            var symbols = new List<string>();
            if (expression[0] == '@' || expression[0] == '#')
            {
                expression = expression.Substring(1, expression.Length - 1);
            }
            else if (expression.Contains(",X"))
            {
                expression = expression.Remove(expression.IndexOf(','));
            }

            if (expression.Contains('+'))
            {
                symbols = new List<string>(expression.Split('+'));
            }
            else if (expression.Contains('-'))
            {
                symbols = new List<string>(expression.Split('-'));
            }
            else
            {
                symbols.Add(expression);
            }

            return symbols.ToArray();
        }
    }
}