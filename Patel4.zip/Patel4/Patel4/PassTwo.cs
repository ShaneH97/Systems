﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler. ***
********************************************************************/
namespace Patel4
{
    public enum Register { A = 0, X = 1, L = 2, B = 3, S = 4, T = 5, F = 6, PC = 8, SW = 9 }
    public static class PassTwo
    {   
        /********************************************************************
        *** FUNCTION PassOne                                              ***
        *********************************************************************
        *** DESCRIPTION : This is the default constructor for OpTable class**
        *** INPUT ARGS : codes                                            ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : int                                                  ***
        ********************************************************************/
        public static void Start_PassTwo(string intermediate_file, PassOne passOne)
        {
            string AssemblyList = intermediate_file.Remove(intermediate_file.IndexOf('.')) + ".txt";
            string AssemblyListPath = Path.Combine(Directory.GetCurrentDirectory(), AssemblyList);
            StreamWriter OFile = new StreamWriter(AssemblyListPath);
            string objectFileName = intermediate_file.Remove(intermediate_file.IndexOf('.')) + ".o";
            string[] Lines = File.ReadAllLines((Path.Combine(Directory.GetCurrentDirectory(), intermediate_file)));
            Console.WriteLine("Pass 2");
            Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", "Line No", "LC", "Label", "Operation", "Operand", "Object Code");
            OFile.WriteLine("Pass 2");
            OFile.WriteLine("-------------------------------------------------------------------------");
            OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", "LINE#", "LC", "LABEL", "OPERATION", "OPERAND", "OBJECT CODE");
            OFile.WriteLine("-------------------------------------------------------------------------");
            int lineNumber = 0;
            bool checkedFormat1 = false;
            string[] inputLine = ReadLine(Lines[lineNumber++]);
            string locationCounter = "0",
                   baseCounter = "0";
            string opcodeAddress = "0", objCode;
            StringBuilder objectRecords = new StringBuilder();
            List<string> textRecord;
            List<string> modificationRecords = new List<string>();

            if (inputLine[3] == "START")
            {
                objectRecords.AppendLine(string.Format("H^{0}^{1}^{2}", inputLine[2], passOne.StartingAddress.PadLeft(6, '0'), passOne.ProgramLength.PadLeft(6, '0')));
                
                Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);

                inputLine = ReadLine(Lines[lineNumber++]);

            }
            textRecord = new List<string>(new string[2] { "T^" + passOne.StartingAddress.PadLeft(6, '0'), passOne.StartingAddress });

            while (inputLine[3] != "END")
            {
                objCode = string.Empty;
                locationCounter = ReadLine(Lines[lineNumber])?[1];
                if (passOne.SrchOpTable(inputLine[3], out Opcode opcode))
                {
                    if (inputLine[4] != string.Empty &&
                        passOne.SearchSymbol(inputLine[4], out Symbol found))
                    {
                        opcodeAddress = found.Value.ToString("X");

                        if (opcode.Format == 4)
                        {
                            if (inputLine[4].Contains("+") || inputLine[4].Contains("-"))
                            {
                                Symbol[] symbols = GetSymbols(passOne, inputLine[4], out char sign);
                                char[] signs = { '+', sign };

                                int i = 0;
                                foreach (var symbol in symbols)
                                    modificationRecords.Add(CreateModification(symbol, (int.Parse(inputLine[1], NumberStyles.HexNumber) + 1).ToString("X"), passOne.ProgramName, "5", signs[i++]));
                            }
                            else if (passOne.SearchSymbol(inputLine[4], out Symbol symbol))
                            {
                                modificationRecords.Add(CreateModification(symbol, (int.Parse(inputLine[1], NumberStyles.HexNumber) + 1).ToString("X"), passOne.ProgramName, "5", '+'));
                            }
                        }
                    }
                    else if (inputLine[4].Contains("="))
                    {
                        foreach (var literal in passOne.LiteralTable)
                        {
                            if (inputLine[4] == literal.Name)
                            {
                                opcodeAddress = literal.Address;
                            }
                        }
                    }
                    else
                    {
                        opcodeAddress = "0";
                    }
                    objCode = AssembleObjectCode(opcode, opcodeAddress, inputLine[4], locationCounter, baseCounter);
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                    OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);

                }
                else if (inputLine[3] == "BYTE")
                {
                    objCode = Expressions.ParseConstant(inputLine[4]).Value;
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                    OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                }
                else if (inputLine[3] == "WORD")
                {
                    if (inputLine[4].Contains("+") || inputLine[4].Contains("-"))
                    {
                        Symbol[] symbols = GetSymbols(passOne, inputLine[4], out char sign);
                        char[] signs = { '+', sign };
                        int i = 0;
                        foreach (var symbol in symbols)
                            modificationRecords.Add(CreateModification(symbol, inputLine[1], passOne.ProgramName, "6", signs[i++]));
                        Expressions.ChkExpr(sign, inputLine[4].Split('+', '-'), symbols, out int value, out bool rFlag);
                        objCode = value.ToString("X").PadLeft(6, '0');
                    }
                    else if (passOne.SearchSymbol(inputLine[4], out Symbol symbol))
                    {
                        modificationRecords.Add(CreateModification(symbol, inputLine[1], passOne.ProgramName, "6", '+'));
                        objCode = symbol.Value.ToString("X").PadLeft(6, '0');
                    }
                    else
                    {
                        objCode = int.Parse(inputLine[4]).ToString("X").PadLeft(6, '0');
                    }

                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                    OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5, -10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                }
                else if (inputLine[3] == "BASE")
                {
                    if (passOne.SearchSymbol(inputLine[4], out Symbol symbol))
                    {
                        baseCounter = symbol.Value.ToString("X");
                    }
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                    OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                }
                else if (inputLine[3] == "EXTREF")
                {
                    objectRecords.Append("R");
                    foreach (var refEntry in inputLine[4].Split(','))
                    {
                        passOne.InsertSymbol(refEntry, "0", false, false, false);
                        objectRecords.Append(refEntry);
                    }
                    objectRecords.AppendLine();
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                }
                else if (inputLine[3] == "EXTDEF")
                {
                    objectRecords.Append("D");
                    foreach (var defEntry in inputLine[4].Split(','))
                    {
                        if (passOne.SearchSymbol(defEntry, out Symbol symbol))
                        {
                            objectRecords.Append(defEntry + symbol.Value.ToString("X").PadLeft(6, '0'));
                        }
                    }
                    objectRecords.AppendLine();
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                }
                else if (inputLine[3] == "RESW" || inputLine[3] == "RESB" || inputLine[3] == "EQU")
                {
                    Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                    OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
                }
                else if (inputLine[3] != "RESW" && inputLine[3] != "RESB")
                {
                    if (!checkedFormat1)
                    {
                        inputLine[2] = inputLine[3];
                        inputLine[3] = inputLine[4];
                        inputLine[4] = string.Empty;
                        checkedFormat1 = true;

                    }
                    else
                    {
                        inputLine = ReadLine(Lines[lineNumber++]);

                    }
                    continue;
                }
                if (objCode != string.Empty && textRecord.Count < 12)
                {
                    textRecord.Add(objCode);
                }
                else if (textRecord.Count > 2)
                {
                    textRecord[1] = (int.Parse(inputLine[1], NumberStyles.HexNumber) - int.Parse(textRecord[1], NumberStyles.HexNumber))
                        .ToString("X").PadLeft(2, '0');
                    textRecord.ForEach(x => objectRecords.Append("^"+x));
                    objectRecords.AppendLine();

                    textRecord = new List<string>(new string[2] { "T^" + inputLine[1].PadLeft(6, '0'),inputLine[1]});

                    if (objCode != string.Empty) textRecord.Add(objCode);
                }
                checkedFormat1 = false;
                inputLine = ReadLine(Lines[lineNumber++]);
            }
            Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);
            OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4]);

            if (textRecord.Count > 2)
            {
                textRecord[1] = (int.Parse(inputLine[1], NumberStyles.HexNumber) - int.Parse(textRecord[1]))
                        .ToString("X").PadLeft(2, '0');
                textRecord.ForEach(x => objectRecords.Append("^" + x));
                objectRecords.AppendLine();

                textRecord = new List<string>(new string[2] { "T^" + inputLine[1].PadLeft(6, '0'), inputLine[1] });
            }

            foreach (var literal in passOne.LiteralTable)
            {
                inputLine = ReadLine(Lines[lineNumber++]);
                objCode = literal.Value;

                Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);
                OFile.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", inputLine[0], inputLine[1], inputLine[2], inputLine[3], inputLine[4], objCode);

                if (textRecord.Count < 12)
                {
                    textRecord.Add(objCode);
                }
                else if (textRecord.Count > 2)
                {
                    textRecord[1] = (int.Parse(inputLine[1], NumberStyles.HexNumber) - int.Parse(textRecord[1], NumberStyles.HexNumber))
                            .ToString("X").PadLeft(2, '0');
                    textRecord.ForEach(x => objectRecords.Append("^" + x));
                    objectRecords.AppendLine();

                    textRecord = new List<string>(new string[2] { "T^" + inputLine[1].PadLeft(6, '0'), inputLine[1] });

                    if (objCode != string.Empty) textRecord.Add(objCode);
                }
            }

            if (textRecord.Count > 2)
            {
                textRecord[1] = (int.Parse(inputLine[1], NumberStyles.HexNumber) - int.Parse(textRecord[1]))
                        .ToString("X").PadLeft(2, '0') ;
                textRecord.ForEach(x => objectRecords.Append("^"+x));
                objectRecords.AppendLine();
            }
            foreach (var mRecord in modificationRecords)
            {
                objectRecords.AppendLine(mRecord);
            }
            objectRecords.AppendLine("E^" + passOne.StartingAddress.PadLeft(6, '0'));
            
            File.WriteAllText(Path.Combine(Directory.GetCurrentDirectory(), objectFileName), objectRecords.ToString());
            Console.WriteLine("Program Length: {0}", passOne.ProgramLength);
            Console.WriteLine();

            Console.WriteLine("Object Records");
            Console.WriteLine(objectRecords.ToString());

            OFile.WriteLine("Program Length: {0}", passOne.ProgramLength);
            OFile.WriteLine("------------------------------------------------------------------");
            OFile.WriteLine("                          Symbol Table                                  ");
            OFile.WriteLine("------------------------------------------------------------------");
            OFile.WriteLine("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10}", "Label", "Value", "RFlag", "IFlag", "MFlag");
            OFile.WriteLine("------------------------------------------------------------------");
            foreach (var symbol in passOne.SymbolTable)
            {
                OFile.WriteLine(symbol);

            }
            OFile.WriteLine("-----------------------------------------------------------------");
            OFile.WriteLine("                         Literal Table                           ");
            OFile.WriteLine("-----------------------------------------------------------------");
            OFile.WriteLine("{0,-12} {1,-18} {2,-10} {3,-10}", "Name", "Value", "Length", "Address");
            OFile.WriteLine("-----------------------------------------------------------------");
            foreach (var literal in passOne.LiteralTable)
            {
                OFile.WriteLine(literal);
            }
            OFile.Close();
        }
        /********************************************************************
        *** FUNCTION CreateModification(Symbol symbol, string location, string programName, string size, char sign)
        *********************************************************************
        *** DESCRIPTION : This is the default constructor for OpTable class**
        *** INPUT ARGS : symbol,location,programName,size,sign
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : string                                               ***
        ********************************************************************/
        private static string CreateModification(Symbol symbol, string location, string programName, string size, char sign)
        {
            StringBuilder mRecord = new StringBuilder("M");

            mRecord.Append("^"+location.PadLeft(6, '0')+"^" );
            mRecord.Append(size.PadLeft(2, '0'));

            if (!symbol.IFlag)
            {
                mRecord.Append("^" + sign + symbol.Name);
            }
            else
            {
                mRecord.Append("^" + sign + (programName.Length > 5 ? programName.Remove(5) : programName));
            }

            return mRecord.ToString();
        }
        /********************************************************************
        *** FUNCTION AssembleObjectCode(Opcode opcode, string address, string expression, string LC, string BC)
        *********************************************************************
        *** DESCRIPTION : This assembles the object code**
        *** INPUT ARGS : opcode,address,expression,lc,bc
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : string                                               ***
        ********************************************************************/
        public static string AssembleObjectCode(Opcode opcode, string address, string expression, string LC, string BC)
        {
            string objectCode = string.Empty;
            if (opcode.Format == 3 || opcode.Format == 4)
            {
                byte[] objInstruction = { byte.Parse(opcode.Opco[0].ToString(), NumberStyles.HexNumber),
                                      byte.Parse(opcode.Opco[1].ToString(), NumberStyles.HexNumber),
                                      0
                                    },
                       objAddressing = Expressions.SetBits(expression);

                string objectAddress = "000";

                objInstruction[1] |= objAddressing[0];
                objInstruction[2] |= objAddressing[1];

                if (opcode.Format == 4)
                {
                    objInstruction[2] |= 0b0001;
                    if (int.TryParse(Expressions.ParseSymbol(expression), out int num))
                        objectAddress = num.ToString("X").PadLeft(5, '0');
                    else
                        objectAddress = address.PadLeft(5, '0');
                }
                else if (opcode.Format == 3)
                {
                    if (int.TryParse(Expressions.ParseSymbol(expression), out int num))
                    {
                        objectAddress = num.ToString("X").PadLeft(3, '0');
                    }
                    else
                    {
                        int counter = 0,
                            addressInt = int.Parse(address, NumberStyles.HexNumber);

                        if (addressInt >= -2048 && addressInt <= 2047)
                        {
                            objInstruction[2] |= 0b0010;
                            counter = int.Parse(LC, NumberStyles.HexNumber);
                        }
                        else if (addressInt >= 0 && addressInt <= 4096)
                        {
                            objInstruction[2] |= 0b0100;
                            counter = int.Parse(BC, NumberStyles.HexNumber);
                        }
                        objectAddress = (addressInt - counter).ToString("X").PadLeft(3, '0');
                    }

                    objectAddress = objectAddress.Substring(objectAddress.Length - 3, 3);
                }

                foreach (var obj in objInstruction)
                {
                    objectCode += obj.ToString("X");
                }
                objectCode += objectAddress;

            }
            else if (opcode.Format == 2)
            {
                string[] splitRegisters = expression.Split(',');
                string regNums = string.Empty;
                objectCode = opcode.Opco;
                foreach (var register in splitRegisters)
                {
                    regNums += (int)(Register)Enum.Parse(typeof(Register), register);
                }
                objectCode += regNums.PadRight(2, '0');
            }
            else if (opcode.Format == 1)
            {
                objectCode = opcode.Opco;
            }

            return objectCode;
        }
        /********************************************************************
        *** FUNCTION ReadLine(string line)
        *********************************************************************
        *** DESCRIPTION : Splits the function from the file
        *** INPUT ARGS : line
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : string                                               ***
        ********************************************************************/
        public static string[] ReadLine(string line)
        {
            char[] splitCatergories = { ' ', '\t' };
            var splitLine = line.Split(splitCatergories, StringSplitOptions.RemoveEmptyEntries);
            string[] returnLine = new string[5];

            if (splitLine.Length == 4)
            {
                returnLine[4] = splitLine[3];
                returnLine[3] = splitLine[2];
                returnLine[2] = string.Empty;
                returnLine[1] = splitLine[1];
                returnLine[0] = splitLine[0];
            }
            else
            {
                returnLine = splitLine;
            }
            return returnLine;
        }
        /********************************************************************
        *** FUNCTION GetSymbols(PassOne pass1, string expression, out char sign)
        *********************************************************************
        *** DESCRIPTION : This gets the operand if it contains a + or - and does operation**
        *** INPUT ARGS : pass1,expression,sign
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : symbol                                               ***
        ********************************************************************/
        public static Symbol[] GetSymbols(PassOne pass1, string expression, out char sign)
        {
            sign = '+';
            List<Symbol> symbolsList = new List<Symbol>();
            foreach (var symString in Expressions.ParseSymbols(expression))
            {
                if (pass1.SearchSymbol(symString, out Symbol symbol))
                {
                    symbolsList.Add(symbol);
                }
            }
            if (expression.Contains("-"))
            {
                sign = '-';
            }
            return symbolsList.ToArray();
        }
    }
}
