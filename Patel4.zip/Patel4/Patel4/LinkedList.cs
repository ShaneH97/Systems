﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler. ***
********************************************************************/
namespace Patel4
{
    class ListNode<T>
    {
        public T element;
        public ListNode<T> Next;
    }
    public class LinkedList<T> : IEnumerable<T>
    {
        public delegate string ToStringHandler();
        private ListNode<T> head;
        /*********************************************************************
        *** FUNCTION LinkedList                                           ***
        *********************************************************************
        *** DESCRIPTION : This is the default Constructor for the LinkedList*
        *** INPUT ARGS : -                                                ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : -                                                    ***
        ********************************************************************/
        public LinkedList()
        {
            head = null;
        }

        /********************************************************************
        *** FUNCTION AppendNode                                          ***
        *********************************************************************
        *** DESCRIPTION : This function appends literal to the literal table*
        *** INPUT ARGS : -                                                ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : void                                                 ***
        ********************************************************************/
        public void AppendNode(T element)
        {
            ListNode<T> newNode = new ListNode<T>()
            {
                element = element,
                Next = null
            };
            ListNode<T> nodeptr;
            if (head == null)
            {
                head = newNode;
            }
            else
            {
                nodeptr = head;
                while (nodeptr.Next != null)
                {
                    if (!nodeptr.element.Equals(newNode.element))
                        nodeptr = nodeptr.Next;
                    else
                    {
                        break;
                    }
                }
                if (!nodeptr.element.Equals(newNode.element))
                    nodeptr.Next = newNode;
            }
        }
        /***********************************************************************
        *** FUNCTION FindNode(T searchNode, out T foundNode)                 ***
        ************************************************************************
        *** DESCRIPTION : This function finds all the literals in the literal **
        *** table                                                            ***
        *** INPUT ARGS : searchNode                                          ***
        *** OUTPUT ARGS : foundNode                                          ***
        *** IN/OUT ARGS : -                                                  ***
        *** RETURN : bool                                                    ***
        ***********************************************************************/
        public bool FindNode(T searchNode, out T foundNode)
        {
            ListNode<T> nodeptr = head;
            while (nodeptr != null)
            {
                if (searchNode.Equals(nodeptr.element))
                {
                    foundNode = nodeptr.element;
                    return true;
                }
                nodeptr = nodeptr.Next;
            }
            foundNode = default(T);
            return false;
        }

        /***********************************************************************
        *** FUNCTION ReplaceNode(T newNode, T previousNode)
        ************************************************************************
        *** DESCRIPTION : This function finds the literals that are dumped in **
        *** at the end of intermediate file and assigns the address to it    ***
        *** table                                                            ***
        *** INPUT ARGS : -                                                   ***
        *** OUTPUT ARGS : -                                                  ***
        *** IN/OUT ARGS : -                                                  ***
        *** RETURN : void                                                    ***
        ***********************************************************************/
        public void ReplaceNode(T newNode, T previousNode)
        {
            ListNode<T> nodeptr = head;
            while (nodeptr != null)
            {
                if (previousNode.Equals(nodeptr.element))
                {
                    nodeptr.element = newNode;
                    break;
                }
                nodeptr = nodeptr.Next;
            }
        }
        /********************************************************************
        *** FUNCTION View                                                 ***
        *********************************************************************
        *** DESCRIPTION : Function to view literal table                  ***
        *** INPUT ARGS : -                                                ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : void                                                 ***
        ********************************************************************/
        public void View()
        {
            Console.WriteLine();
            Console.WriteLine("Literal Table");
            Console.WriteLine("{0,-12} {1,-18} {2,-10} {3,-10}", "Name", "Value", "Length", "Address");
            ListNode<T> nodeptr = head;
            if (nodeptr == null)
            {
                Console.WriteLine("No Literals");
            }
            while (nodeptr != null)
            {
                Console.WriteLine(nodeptr.element.ToString());
                nodeptr = nodeptr.Next;
              
            }
        }
        /********************************************************************
        *** FUNCTION GetEnumerator()                                    ***
        *********************************************************************
        *** DESCRIPTION : Function to use literal table in a foreach loop ***
        *** INPUT ARGS : -                                                ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : -                                                    ***
        ********************************************************************/
        public IEnumerator<T> GetEnumerator()
        {
            ListNode<T> nodeptr = head;
            while (nodeptr != null)
            {
                yield return nodeptr.element;
                nodeptr = nodeptr.Next;
            }
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}