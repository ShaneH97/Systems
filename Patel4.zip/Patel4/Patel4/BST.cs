﻿using System;
using System.Collections.Generic;
using System.Collections;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : Pass 2***
*** DUE DATE : NOV 27, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program is the pass 2 for the SICXE assembler.***
********************************************************************/
namespace Patel4
{
    public class BSTNode<T>
    {
        public T OneElement;
        public BSTNode<T> Left, Right;
    }
    public class BST<T> : IEnumerable<T>
    {
        private BSTNode<T> theTree;
        private IComparer<T> comparer;
        /********************************************************************
        *** FUNCTION BST(IComparer<T> comparer) ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public BST(IComparer<T> comparer)
        {
            theTree = null;
            this.comparer = comparer;
        }
        /********************************************************************
        *** FUNCTION : Insertnode(T node)
        *********************************************************************
        *** DESCRIPTION : This functions calls the private function to insert 
        * symbols in the symbol table
        *** INPUT ARGS : T node
        *** OUTPUT ARGS : -
        *** IN/OUT ARGS : -
        *** RETURN : void
        ********************************************************************/
        public void Insertnode(T node)
        {
            Insertnode(node, ref theTree);
        }
        /********************************************************************** 
         **** FUNCTION : Insertnode(T node, ref BSTNode<T> theTree)
         **********************************************************************  
         **** DESCRIPTION : This function inserts the symbols in the symbol table 
         **** INPUT ARGS : T node, T theTree
         **** OUTPUT ARGS : -
         **** IN/OUT ARGS : -  
         **** RETURN : void  
         *********************************************************************/
        private void Insertnode(T node, ref BSTNode<T> theTree)
        {
            if (theTree == null)
            {
                theTree = new BSTNode<T>
                {
                    OneElement = node,
                    Left = null,
                    Right = null
                };
            }
            else if (comparer.Compare(node, theTree.OneElement) < 0)
            {
                Insertnode(node, ref theTree.Left);
            }
            else if (comparer.Compare(node, theTree.OneElement) > 0)
            {
                Insertnode(node, ref theTree.Right);
            }
        }
        /********************************************************************
         *** FUNCTION : SearchNode
         *********************************************************************
         *** DESCRIPTION : This functions calls the private function to search if the
         *** node is present in the Binary Search Tree
         *** INPUT ARGS : T searchElement, out T foundElement
         *** OUTPUT ARGS : bool
         *** IN/OUT ARGS : -
         *** RETURN : Symbol
         ********************************************************************/
        public bool SearchNode(T searchElement, out T foundElement)
        {
            var returnSymbol = SearchNode(searchElement, theTree);

            if (returnSymbol != null)
            {
                foundElement = returnSymbol.OneElement;
                return true;
            }
            else
            {
                foundElement = default(T);
                return false;
            }
        }
        /********************************************************************
        *** FUNCTION :  SearchNode                                        ***
        *********************************************************************
        *** DESCRIPTION : This function search the nodes and looks for the*** 
        ***values in the tree.                                            ***
        *** INPUT ARGS : T_sym_node,BSTNode<T> theTree                   ***
        *** OUTPUT ARGS : -                                               ***
        *** IN/OUT ARGS : -                                               ***
        *** RETURN : BSTNode                                              *** 
        ********************************************************************/
        private BSTNode<T> SearchNode(T sym_node, BSTNode<T> theTree)
        {
            if (theTree == null)
            {
                return null;
            }
            else if (comparer.Compare(sym_node, theTree.OneElement) < 0)
            {
                return SearchNode(sym_node, theTree.Left);
            }
            else if (comparer.Compare(sym_node, theTree.OneElement) > 0)
            {
                return SearchNode(sym_node, theTree.Right);
            }
            else
            {
                return theTree;
            }
        }
        /********************************************************************
        *** FUNCTION : InView
        *********************************************************************
        *** DESCRIPTION : This public function calls the InView that prints the
        *** symbol table using in order traversal
        *** INPUT ARGS : -
        *** OUTPUT ARGS : - 
        *** RETURN : void
        ********************************************************************/
        public void InView()
        {
            InView(theTree);
        }
        /********************************************************************
        *** FUNCTION : InView(BSTNode<T> theTree)
        *********************************************************************
        *** DESCRIPTION : This function uses in order traversal to print the 
        *** the symbol table
        *** INPUT ARGS : BSTNode<T> theTree
        *** OUTPUT ARGS : -
        *** IN/OUT ARGS : -
        *** RETURN : void
        ********************************************************************/
        private void InView(BSTNode<T> theTree)
        {
            if (theTree != null)
            {
                if (theTree.Left != null)
                    InView(theTree.Left);
                Console.WriteLine(theTree.OneElement.ToString());

                if (theTree.Right != null)
                    InView(theTree.Right);
            }
        }
        /********************************************************************
        *** FUNCTION : GetEnumerator()
        *********************************************************************
        *** DESCRIPTION : This function recursiviley get the nodes so that it is used 
        *** in a for each
        *** INPUT ARGS : -
        *** OUTPUT ARGS : -
        *** IN/OUT ARGS : -
        *** RETURN : void
        ********************************************************************/
        public IEnumerator<T> GetEnumerator()
        {
            var nodes = new List<T>();

            GetAllNodes(ref nodes, theTree);

            return nodes.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        /********************************************************************
        *** FUNCTION : GetAllNodes(ref List<T> nodes, BSTNode<T> tree)
        *********************************************************************
        *** DESCRIPTION : This function recursiviley get the nodes so that it is used 
        *** in a for each 
        *** INPUT ARGS : List<T> nodes, BSTNode<T> tree
        *** OUTPUT ARGS : -
        *** IN/OUT ARGS : -
        *** RETURN : void
        ********************************************************************/
        private void GetAllNodes(ref List<T> nodes, BSTNode<T> tree)
        {
            if (tree != null)
            {
                if (tree.Left != null)
                    GetAllNodes(ref nodes, tree.Left);
                nodes.Add(tree.OneElement);
                if (tree.Right != null)
                    GetAllNodes(ref nodes, tree.Right);
            }
        }
    }
}