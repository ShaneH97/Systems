﻿using System;
/********************************************************************
* NAME : Meet Patel                                             *
* CLASS : CSC 354                                               *
* ASSIGNMENT : SYMBOL TABLE                                     *
* DUE DATE : 9/13/2018                                          *
* INSTRUCTOR : Mr. Werpy                                        *
*******************************************************************
* DESCRIPTION : This program reads from the file that contains  *
* information about the symbol, values and the flags (rflag,    *
* iflag, mflag) check for the validation                        *
********************************************************************/
namespace Patel1
{
    
    class Program
    {
        /********************************************************************
        *** FUNCTION <Main()> ***
        *********************************************************************
        *** DESCRIPTION : <Main Driver Program> ***
        *** INPUT ARGS : <args> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        static void Main(string[] args)
        {
            SymbolTable read_txt = new SymbolTable();
            read_txt.ReadFile();

            Console.WriteLine();
            Console.WriteLine("Assignment 1 has ended");
            Console.Read();
        }
    }
}