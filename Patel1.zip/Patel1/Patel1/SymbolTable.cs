﻿using System;
using System.IO;
/********************************************************************
* NAME : Meet Patel                                             *
* CLASS : CSC 354                                               *
* ASSIGNMENT : SYMBOL TABLE                                     *
* DUE DATE : 9/13/2018                                          *
* INSTRUCTOR : Mr. Werpy                                        *
*******************************************************************
* DESCRIPTION : This program reads from the file that contains  *
* information about the symbol, values and the flags (rflag,    *
* iflag, mflag) check for the validation                        *
********************************************************************/
namespace Patel1
{
    class SymbolTable
    {
        private readonly BST searchTree = new BST();
        /********************************************************************
        *** FUNCTION <SymbolCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Validate symbol> ***
        *** INPUT ARGS : <line> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private bool SymbolCheck(string line)
        {
            string symbol_string = line.ToUpper();
            int symbol_length = symbol_string.Length;
            //Symbol length has to be 10 chars
            if (symbol_length <= 10)
            {
                //Symbol first letter has to be a letter
                if (char.IsLetter(symbol_string[0]))
                {
                    //checks each character in symbol for specifics
                    foreach (char character in symbol_string.Substring(1))
                    {
                        if (!(char.IsLetter(character) || char.IsDigit(character) || character.Equals('-')))
                        {
                            Console.WriteLine(string.Format("{0} -> Error: Symbol has an invalid character(s).", symbol_string.Substring(0, 5)));
                            return false;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("{0} -> Error: Symbol has to start with a letter.", symbol_string);
                    return false;
                }
            }
            else
            {
                Console.WriteLine(string.Format("{0} -> Error: Symbol has maximum of 10 characters.", symbol_string.Substring(0, 5)));
                return false;
            }
            return true;
        }
        /********************************************************************
        *** FUNCTION <ValueCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Validate value> ***
        *** INPUT ARGS : <value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <newValue> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private bool ValueCheck(string value, out int newValue)
        {
            if (int.TryParse(value, out newValue))
            {
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Value is invalid.", value);
                return false;
            }
        }
        /********************************************************************
       *** FUNCTION <RflagCheck> ***
       *********************************************************************
       *** DESCRIPTION : <Validate rflag> ***
       *** INPUT ARGS : <rflag> ***
       *** OUTPUT ARGS : <None> ***
       *** IN/OUT ARGS : <boolFlag> ***
       *** RETURN : <bool> ***
       ********************************************************************/
        private bool RflagCheck(string rflag, out bool boolFlag)
        {
            string flag = rflag.ToUpper();
            if (flag == "TRUE" || flag == "1" || flag == "T")
            {
                boolFlag = true;
                return true;
            }
            else if (flag == "FALSE" || flag == "0" || flag == "F")
            {
                boolFlag = false;
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Rflag is invalid.", flag);
                boolFlag = false;
                return false;
            }
        }
        /********************************************************************
       *** FUNCTION <Readfile> ***
       *********************************************************************
       *** DESCRIPTION : <Submain that checks if file/symbol/value/rflag is valid>
       *                 < to print it> ***
       *** INPUT ARGS : <None> ***
       *** OUTPUT ARGS : <None> ***
       *** IN/OUT ARGS : <None> ***
       *** RETURN : <void> ***
       ********************************************************************/
        public void ReadFile()
        {
            try
            {

                string path = Path.Combine(Directory.GetCurrentDirectory(), "SYMBOLS.DAT");
                while (!File.Exists(path))
                {
                    Console.WriteLine("Error: SYMBOLS.DAT file does not exist.");
                    Console.Write("Enter the file name: ");
                    var input = Console.ReadLine();
                    path = Path.Combine(Directory.GetCurrentDirectory(), input + (input.Contains(".dat") ? "" : ".dat"));
                }
                if (File.Exists(path))
                {
                    Console.WriteLine("----------------Error Log-------------------------");
                    Console.WriteLine("--------------------------------------------------");

                    string[] lines = File.ReadAllLines(path);
                    foreach (string line in lines)
                    {
                        string[] splitText = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (splitText.Length >= 3)
                        {
                            if (SymbolCheck(splitText[0]) && ValueCheck(splitText[1], out int value) && RflagCheck(splitText[2], out bool rFlag))
                            {
                                var symbol = new Symbol()
                                {
                                    Element = splitText[0],
                                    Value = value,
                                    RFlag = rFlag,
                                    IFlag = true,
                                    MFlag = false
                                };
                                this.searchTree.Insert(symbol);
                            }
                        }
                        else
                        {
                            Console.WriteLine("{0} -> Error: an attribute is missing.", line);
                        }
                    }
                }
                Console.WriteLine();
                Console.Write("PRESS ANY KEY TO VIEW SYMBOL TABLE");
                Console.Read();
                Console.Clear();
                Console.ReadLine();
                this.searchTree.View();
                string path1 = Path.Combine(Directory.GetCurrentDirectory());
                while (!File.Exists(path1))
                {
                    Console.Write("Enter the search file name or path: ");
                    path1 = Console.ReadLine();
                }

                if (File.Exists(path1))
                {
                    string splitText;
                    string[] lines = File.ReadAllLines(path1);
                    foreach (var line in lines)
                    {
                        splitText = line.Trim();
                        splitText = splitText.ToUpper();
                        if (splitText.Length > 5)
                        {
                            splitText = splitText.Substring(0, 5);
                        }
                        if (searchTree.Search(splitText) != null)
                        {
                            Console.WriteLine("{0} Success -> Symbol is found", splitText);
                        }
                        else if (searchTree.Search(splitText) == null)
                        {
                            Console.WriteLine("{0} Error -> Symbol is not found", splitText);
                        }

                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            }
    }

} 