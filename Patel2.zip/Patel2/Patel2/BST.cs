﻿using System;
/********************************************************************
* NAME : Meet Patel                                             *
* CLASS : CSC 354                                               *
* ASSIGNMENT : SYMBOL TABLE                                     *
* DUE DATE : 9/13/2018                                          *
* INSTRUCTOR : Mr. Werpy                                        *
*******************************************************************
* DESCRIPTION : This program reads from the file that contains  *
* information about the symbol, values and the flags (rflag,    *
* iflag, mflag) check for the validation                        *
********************************************************************/
namespace Patel2
{
    public struct Symbol
    {
        public string Name;
        public int Value;
        public bool RFlag, MFlag, IFlag;
    }
    public class BSTNode
    {
        public BSTNode Left;
        public BSTNode Right;
        public Symbol Element;
    }
    class BST
    {
        private BSTNode myTree;
        /********************************************************************
        *** FUNCTION <BST()> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public BST()
        {
            myTree = null;
        }
        /********************************************************************
        *** FUNCTION <Insert()> ***
        *********************************************************************
        *** DESCRIPTION : <Insert the Symbol> ***
        *** INPUT ARGS : <symbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void Insert(Symbol symbol)
        {
            Insert(symbol, ref myTree);
        }
        /********************************************************************
        *** FUNCTION <View()> ***
        *********************************************************************
        *** DESCRIPTION : <View the tree> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void View()
        {
            //Console.WriteLine();
            Console.WriteLine("----------------SYMBOL TABLE----------------------");
            Console.WriteLine("Symbol".PadRight(10) + "Value".PadRight(10) + "RFlag".PadRight(10) + "IFlag".PadRight(10) + "MFlag".PadRight(10));
            Console.WriteLine("--------------------------------------------------");
            PreView(myTree);
            Console.WriteLine("--------------------------------------------------");
        }
        /********************************************************************
        *** FUNCTION <Search()> ***
        *********************************************************************
        *** DESCRIPTION : <Search the Symbol> ***
        *** INPUT ARGS : <value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <BSTNode> ***
        ********************************************************************/
        public BSTNode Search(string value)
        {
            BSTNode Tree = new BSTNode();
            Tree = Search(myTree, value);
            return Tree;
        }
        /********************************************************************
        *** FUNCTION <Search()> ***
        *********************************************************************
        *** DESCRIPTION : <Search into Binary Search Tree> ***
        *** INPUT ARGS : <root, value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <BSTNode> ***
        ********************************************************************/
        private BSTNode Search(BSTNode root, string value)
        {
            if (root == null)
            {
                return null;
            }
            else if (string.Compare(root.Element.Name, value.ToUpper()) < 0)
            {
                return Search(root.Right, value);
            }
            else if (string.Compare(root.Element.Name, value.ToUpper()) > 0)
            {
                return Search(root.Left, value);
            }
            else if (string.Compare(root.Element.Name, value.ToUpper()) == 0)
            {
                return root;
            }
            return null;
        }
        /********************************************************************
        *** FUNCTION <Insert()> ***
        *********************************************************************
        *** DESCRIPTION : <Insert into Binary Search Tree> ***
        *** INPUT ARGS : <symbol, root> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void Insert(Symbol symbol, ref BSTNode root)
        {
            if (symbol.Name.Length <= 5)
                symbol.Name = symbol.Name.Trim().ToUpper();
            else
                symbol.Name = symbol.Name.Substring(0, 5).ToUpper();
            var newNode = new BSTNode
            {
                Left = null,
                Right = null,
                Element = symbol
            };
            if (root == null)
                root = newNode;
            else if (string.Compare(symbol.Name, root.Element.Name) < 0)
                Insert(symbol, ref root.Left);
            else if (string.Compare(symbol.Name, root.Element.Name) > 0)
                Insert(symbol, ref root.Right);
            else if (string.Compare(symbol.Name, root.Element.Name) == 0)
            {
                root.Element.MFlag = true;
                Console.WriteLine("{0} -> Symbol exists already.", symbol.Name);
            }
        }
        /********************************************************************
        *** FUNCTION <PreView()> ***
        *********************************************************************
        *** DESCRIPTION : <View the tree> ***
        *** INPUT ARGS : <mytree> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private int lines = 0;
        private void PreView(BSTNode myTree)
        {
            if (myTree != null)
            {
                if (myTree.Left != null)
                    PreView(myTree.Left);
                Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10}", myTree.Element.Name, myTree.Element.Value, myTree.Element.RFlag ? 1 : 0, myTree.Element.IFlag ? 1 : 0, myTree.Element.MFlag ? 1 : 0);
                if (lines >= 20)
                {
                    Console.Write("Press Enter to Continue");
                    Console.ReadLine();
                    Console.Clear();
                    Console.WriteLine("----------------SYMBOL TABLE----------------------");
                    Console.WriteLine("Symbol".PadRight(10) + "Value".PadRight(10) + "RFlag".PadRight(10) + "IFlag".PadRight(10) + "MFlag".PadRight(10));
                    Console.WriteLine("--------------------------------------------------");
                    lines = 0;
                }
                lines++;
                if (myTree.Right != null)
                    PreView(myTree.Right);
            }
        }
    }
}