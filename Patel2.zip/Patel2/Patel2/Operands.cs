﻿using System;
using System.IO;
using System.Collections.Generic;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : OPERANDS***
*** DUE DATE : OCT 11, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program evaluates the operand field of an assembly
                  language statement. ***
********************************************************************/
namespace Patel2
{
    public struct Literal
    {
        public string name;
        public string value;
        public int length;
        public string address;
    };
    class Operands
    {
        private SymbolTable searchExpression;
        int addrCounter = 0;
        //List<string> errorLog = new List<string>();
        List<string> expressionLog = new List<string>();
        LiteralList LiteralTable = new LiteralList();
        /********************************************************************
        *** FUNCTION <Operands> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <expression> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public Operands(SymbolTable expression)
        {
            searchExpression = expression;
        }
        /********************************************************************
        *** FUNCTION <LiteralHandle> ***
        *********************************************************************
        *** DESCRIPTION : <Validate Literal> ***
        *** INPUT ARGS : <expression> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void LiteralHandle(string expression)
        {
            var literal = new Literal();
            string values = string.Empty;
            if (expression[0] == '=')
            {
                literal.name = expression;
                try
                {
                    if (expression[2] != '\'')
                    {
                        throw new FormatException("Needs single quote at the begining of the literal.");
                    }
                    for (int count = 3; expression[count] != '\''; count++)
                    {
                        values += expression[count];
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    throw new FormatException("Needs single quote at the end of the literal.");
                }
                if (expression[1] == 'C'||expression[1] == 'c')
                {
                    foreach (var value in values)
                    {
                        literal.value += ((int)value).ToString("X");
                        literal.length++;
                    }
                    if (!LiteralTable.Find(literal))
                    {
                        addrCounter++;
                        literal.address = addrCounter.ToString("X");
                        LiteralTable.AppendNode(literal);
                    }
                }
                else if (expression[1] == 'X'||expression[1] == 'x')
                {
                    foreach (var value in values)
                    {
                        try
                        {
                            if (int.TryParse(value.ToString(), System.Globalization.NumberStyles.HexNumber, null, out int i))
                            {
                                literal.value += value;
                            }
                            else
                            {
                                throw new FormatException();
                            }
                        }
                        catch (FormatException)
                        {
                            throw new FormatException("Not a hex digit.");
                        }
                    }
                    if (literal.value.Length % 2 != 0)
                    {
                        throw new FormatException("Odd number of X Bits.");
                    }
                    literal.length = literal.value.Length / 2;
                    if (!LiteralTable.Find(literal))
                    {
                        addrCounter++;
                        literal.address = addrCounter.ToString("X");
                        literal.value = literal.value.ToUpper();
                        LiteralTable.AppendNode(literal);
                    }
                }
                else
                {
                    throw new FormatException("Has to be =X or =C.");
                }             
            }
        }
        /********************************************************************
        *** FUNCTION <ExpressionHandle> ***
        *********************************************************************
        *** DESCRIPTION : <Validate Expression> ***
        *** INPUT ARGS : <expression> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void ExpressionHandle(string expression)
        {

            string ogExpression = expression;
            Symbol searchSymbol = new Symbol();
            bool relocatable = false;
            int value = 0;

            SetBits(expression, out bool Nbit, out bool Ibit, out bool Xbit);
     
            try
            {
                if (expression[0] == '@' || expression[0] == '#')
                {
                    expression = expression.Substring(1, expression.Length - 1);
                    if (expression.Contains(",X")||expression.Contains(",x"))
                    {
                        throw new FormatException("Cannot have indexing with immediate or indirect addressing.");
                    }
                }
                if (expression.Contains("+") || expression.Contains("-"))
                {
                    bool isAddition = expression.Contains("+");
                    string[] arithmeticValues;
                    List<Symbol> arithmeticSymbols = new List<Symbol>();
                    arithmeticValues = isAddition ? expression.Split('+') : expression.Split('-');
                    if (expression[0] != '-')
                    {
                        if(arithmeticValues[1].Contains(",x")||arithmeticValues[1].Contains(",X"))
                        {
                            arithmeticValues[1] = arithmeticValues[1].Substring(0, arithmeticValues[1].Length - 2);
                        }
                        foreach (var item in arithmeticValues)
                        {
                            if (char.IsLetter(item[0]))
                                arithmeticSymbols.Add(searchExpression.Search(item));
                        }
                        EvaluateArithmeticExpression(isAddition ? '+' : '-', arithmeticValues, arithmeticSymbols.ToArray(), out relocatable, out value);
                    }
                    else
                    {
                        Int32.TryParse(expression, out value);
                    }
                }
                else
                {
                    if (char.IsLetter(expression[0]))
                    {
                        if (expression.Contains(",x") || expression.Contains(",X"))
                        {
                            expression = expression.Remove(expression.IndexOf(','));
                            searchSymbol = searchExpression.Search(expression);
                            value = searchSymbol.Value;
                            relocatable = searchSymbol.RFlag;
                        }
                        else
                        {
                            searchSymbol = searchExpression.Search(expression);
                            value = searchSymbol.Value;
                            relocatable = searchSymbol.RFlag;
                        }
                        
                    }
                    else if (char.IsDigit(expression[0]))
                    {
                        value = int.Parse(expression);
                        relocatable = false;
                    }
                    else
                    {
                        throw new FormatException("Incorrect format.");
                    }
                }
                expressionLog.Add(string.Format("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10} {5, -10}", ogExpression, value, relocatable ? "RELATIVE" : "ABSOLUTE", Nbit ? 1 : 0, Ibit ? 1 : 0, Xbit ? 1 : 0));
                //errorLog.Add(string.Format("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10} {5, -10}", ogExpression, value, relocatable ? "RELATIVE" : "ABSOLUTE", Nbit ? 1 : 0, Ibit ? 1 : 0, Xbit ? 1 : 0));
            }
            catch (NullReferenceException)
            {
                throw new NullReferenceException("Symbol not found.");
            }
        }
        /********************************************************************
        *** FUNCTION <EvaluateArithemeticExpressions> ***
        *********************************************************************
        *** DESCRIPTION : <Evaluate arimetic expression ie containing +.-.nothing> ***
        *** INPUT ARGS : <opertorType,values,symbols> ***
        *** OUTPUT ARGS : <adjustflag,value> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void EvaluateArithmeticExpression(char operatorType, string[] values, Symbol[] symbols, out bool adjustedRFlag, out int value)
        {
            bool firstIsSymbol = char.IsLetter(values[0][0]),
                 secondIsSymbol = char.IsLetter(values[1][0]);
            if (operatorType == '+')
            {
                if (firstIsSymbol && secondIsSymbol)
                {
                    value = symbols[0].Value + symbols[1].Value;
                    adjustedRFlag = AdjustRFlag(operatorType, symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (firstIsSymbol && !secondIsSymbol)
                {
                    value = symbols[0].Value + int.Parse(values[1]);
                    adjustedRFlag = AdjustRFlag(operatorType, symbols[0].RFlag, false);
                }
                else if (!firstIsSymbol && secondIsSymbol)
                {
                    value = int.Parse(values[0]) + symbols[0].Value;
                    adjustedRFlag = AdjustRFlag(operatorType, false, symbols[0].RFlag);
                }
                else
                {
                    value = int.Parse(values[0]) + int.Parse(values[1]);
                    adjustedRFlag = AdjustRFlag(operatorType, false, false);
                }
            }
            else if (operatorType == '-')
            {
                if (firstIsSymbol && secondIsSymbol)
                {
                    value = symbols[0].Value - symbols[1].Value;
                    adjustedRFlag = AdjustRFlag(operatorType, symbols[0].RFlag, symbols[1].RFlag);
                }
                else if (firstIsSymbol && !secondIsSymbol)
                {
                    value = symbols[0].Value - int.Parse(values[1]);
                    adjustedRFlag = AdjustRFlag(operatorType, symbols[0].RFlag, false);
                }
                else if (!firstIsSymbol && secondIsSymbol)
                {
                        value = int.Parse(values[0]) - symbols[0].Value;
                        adjustedRFlag = AdjustRFlag(operatorType, false, symbols[0].RFlag);
                }
                else
                {
                    value = int.Parse(values[0]) - int.Parse(values[1]);
                    adjustedRFlag = AdjustRFlag(operatorType, false, false);
                }
            }
            else
            {
                value = 0;
                adjustedRFlag = false;
            }
        }
        /********************************************************************
        *** FUNCTION <AdjustedFlag> ***
        *********************************************************************
        *** DESCRIPTION : <Validate Reloacatable flag> ***
        *** INPUT ARGS : <operatorType,rLeft,rRight> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private bool AdjustRFlag(char operatorType, bool rLeft, bool rRight)
        {
            if (operatorType == '+')
            {
                if (!rLeft && rRight)
                    return true;
                else if (!rLeft && !rRight)
                    return false;
                else if (rLeft && !rRight)
                    return true;
                else if (rLeft && rRight)
                    throw new InvalidOperationException("Error -> RELATIVE + RELATIVE");
            }
            else if (operatorType == '-')
            {
                if (!rLeft && !rRight)
                    return false;
                else if (!rLeft && rRight)
                    throw new InvalidOperationException("Error -> ABSOLUTE - RELATIVE");
                else if (rLeft && !rRight)
                    return true;
                else if (rLeft && rRight)
                    return false;
            }
            return false;
        }
        /********************************************************************
        *** FUNCTION <SetBits()> ***
        *********************************************************************
        *** DESCRIPTION : <Checks and sets the bits> ***
        *** INPUT ARGS : <expression> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <Nbit,Ibit,Xbit> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void SetBits(string expression, out bool Nbit, out bool Ibit, out bool Xbit)
        {
            if (expression.Contains(",X")||expression.Contains(",x"))
            {
                Xbit = true;
            }
            else
            {
                Xbit = false;
                if (expression[0] == '@')
                {
                    Nbit = true;
                    Ibit = false;
                    return;

                }
                if (expression[0] == '#')
                {
                    Nbit = false;
                    Ibit = true;
                    return;
                }
            }
            if (char.IsDigit(expression[0]))
            {
                Nbit = false;
                Ibit = true;
                return;
            }
            if (expression[0] == '-')
            {
                Nbit = false;
                Ibit = true;
                return;
            }
            Nbit = true;
            Ibit = true;
        }
        /********************************************************************
        *** FUNCTION <ViewLiteralTable> ***
        *********************************************************************
        *** DESCRIPTION : <View LiteralTable> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void ViewLiteralTable()
        {
            LiteralTable.View();

        }
        /********************************************************************
        *** FUNCTION <ViewExpressionTable> ***
        *********************************************************************
        *** DESCRIPTION : <View Expression Table> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void ViewExpressionTable()
        {
            Console.WriteLine("----------------EXPRESSION TABLE----------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------");
            Console.WriteLine("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10} {5,-10}", "Expression", "Value", "Relocatable", "N-Bit", "I-Bit", "X-Bit");
            Console.WriteLine("------------------------------------------------------------------------");
            foreach (var item in expressionLog)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("------------------------------------------------------------------------");
        }
        /********************************************************************
        *** FUNCTION <ViewErrors> ***
        *********************************************************************
        *** DESCRIPTION : <View Expression Table> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        private void ViewErrors()
        {
            foreach (var item in expressionLog)
            {
                    Console.WriteLine(item);
            }
        }
        /********************************************************************
        *** FUNCTION <Readfile> ***
        *********************************************************************
        *** DESCRIPTION : <Submain that checks if file/operand is valid>
        *** INPUT ARGS : <fileName> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void ReadFile(string fileName)
        {
            string path = Path.Combine(Directory.GetCurrentDirectory(), fileName);
            while (!File.Exists(path))
            {
                Console.WriteLine("Error: Expression.txt file does not exist.");
                Console.Write("Enter the file name: ");
                var input = Console.ReadLine();
                path = Path.Combine(Directory.GetCurrentDirectory(), input + (input.Contains(".txt") ? "" : ".txt"));
            }
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                foreach (string expression in lines)
                {
                    string oneline = expression.Replace(" ", string.Empty);
                    try
                    {
                        if (oneline[0] == '=')
                        {
                            LiteralHandle(oneline);
                        }
                        else if(oneline[0]=='@'||oneline[0]=='#'||char.IsLetterOrDigit(oneline[0])||oneline[0]=='-')
                        {
                            ExpressionHandle(oneline);
                        }
                    }
                    catch (FormatException ex)
                    {
                        expressionLog.Add(string.Format("Format Error {0} -> {1}", expression, ex.Message));
                    }
                    catch(NullReferenceException ex)
                    {
                        expressionLog.Add(string.Format("Null Reference Error {0} -> {1}", expression, ex.Message));
                    }
                    catch(InvalidOperationException ex)
                    {
                        expressionLog.Add(string.Format("Invalid Operation Error {0} -> {1}", expression, ex.Message));
                    }
                }
                Console.WriteLine("Press any key to continue to view Expression Table.");
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine("----------------EXPRESSION TABLE----------------------------------------");
                Console.WriteLine("------------------------------------------------------------------------");
                Console.WriteLine("{0,-10} {1,-10} {2,-15} {3,-10} {4,-10} {5,-10}", "Expression", "Value", "Relocatable", "N-Bit", "I-Bit", "X-Bit");
                Console.WriteLine("------------------------------------------------------------------------");
                ViewErrors();
                Console.WriteLine("------------------------------------------------------------------------");
                Console.WriteLine("Press any key to continue to view Literal Table.");
                Console.ReadKey();
                Console.Clear();
                ViewLiteralTable();
                Console.WriteLine("Assignment 2 has ended.");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}