﻿using System;
using System.IO;
/********************************************************************
* NAME : Meet Patel                                             *
* CLASS : CSC 354                                               *
* ASSIGNMENT : SYMBOL TABLE                                     *
* DUE DATE : 9/13/2018                                          *
* INSTRUCTOR : Mr. Werpy                                        *
*******************************************************************
* DESCRIPTION : This program reads from the file that contains  *
* information about the symbol, values and the flags (rflag,    *
* iflag, mflag) check for the validation                        *
********************************************************************/
namespace Patel2
{
    class SymbolTable
    {
        private readonly BST searchTree = new BST();
        /********************************************************************
        *** FUNCTION <SymbolCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Validate symbol> ***
        *** INPUT ARGS : <line> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private bool SymbolCheck(string line)
        {
            string symbol_string = line.ToUpper();
            int symbol_length = symbol_string.Length;
            //Symbol length has to be 10 chars
            if (symbol_length <= 10)
            {
                //Symbol first letter has to be a letter
                if (char.IsLetter(symbol_string[0]))
                {
                    //checks each character in symbol for specifics
                    foreach (char character in symbol_string.Substring(1))
                    {
                        if (!(char.IsLetter(character) || char.IsDigit(character)))
                        {
                            Console.WriteLine(string.Format("{0} -> Error: Symbol has an invalid character(s).", symbol_string.Substring(0, 5)));
                            return false;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("{0} -> Error: Symbol has to start with a letter.", symbol_string);
                    return false;
                }
            }
            else
            {
                Console.WriteLine(string.Format("{0} -> Error: Symbol has maximum of 10 characters.", symbol_string.Substring(0, 5)));
                return false;
            }
            return true;
        }
        /********************************************************************
        *** FUNCTION <ValueCheck> ***
        *********************************************************************
        *** DESCRIPTION : <Validate value> ***
        *** INPUT ARGS : <value> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <newValue> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        private bool ValueCheck(string value, out int newValue)
        {
            if (int.TryParse(value, out newValue))
            {
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Value is invalid.", value);
                return false;
            }
        }
        /********************************************************************
       *** FUNCTION <RflagCheck> ***
       *********************************************************************
       *** DESCRIPTION : <Validate rflag> ***
       *** INPUT ARGS : <rflag> ***
       *** OUTPUT ARGS : <None> ***
       *** IN/OUT ARGS : <boolFlag> ***
       *** RETURN : <bool> ***
       ********************************************************************/
        private bool RflagCheck(string rflag, out bool boolFlag)
        {
            string flag = rflag.ToUpper();
            if (flag == "TRUE" || flag == "1" || flag == "T")
            {
                boolFlag = true;
                return true;
            }
            else if (flag == "FALSE" || flag == "0" || flag == "F")
            {
                boolFlag = false;
                return true;
            }
            else
            {
                Console.WriteLine("{0} -> Error: Rflag is invalid.", flag);
                boolFlag = false;
                return false;
            }
        }
        /********************************************************************
       *** FUNCTION <Readfile> ***
       *********************************************************************
       *** DESCRIPTION : <Submain that checks if file/symbol/value/rflag is valid>
       *                 < to print it> ***
       *** INPUT ARGS : <None> ***
       *** OUTPUT ARGS : <None> ***
       *** IN/OUT ARGS : <None> ***
       *** RETURN : <void> ***
       ********************************************************************/
        public void ReadFile()
        {
            try
            {
                string path = Path.Combine(Directory.GetCurrentDirectory(), "SYMBOLS.DAT");
                while (!File.Exists(path))
                {
                    Console.WriteLine("Error: SYMBOLS.DAT file does not exist.");
                    Console.Write("Enter the file name: ");
                    var input = Console.ReadLine();
                    path = Path.Combine(Directory.GetCurrentDirectory(), input);
                }
                if (File.Exists(path))
                {
                    string[] lines = File.ReadAllLines(path);
                    Console.WriteLine("----------------SYMBOL ERROR LOG----------------------");
                    Console.WriteLine("------------------------------------------------------");
                    foreach (string line in lines)
                    {
                        string[] splitText = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (splitText.Length >= 3)
                        {
                            if (SymbolCheck(splitText[0]) && ValueCheck(splitText[1], out int value) && RflagCheck(splitText[2], out bool rFlag))
                            {
                                var symbol = new Symbol()
                                {
                                    Name = splitText[0],
                                    Value = value,
                                    RFlag = rFlag,
                                    IFlag = true,
                                    MFlag = false
                                };
                                this.searchTree.Insert(symbol);
                            }
                        }
                        else
                        {
                            Console.WriteLine("{0} -> Error: an attribute is missing.", line);
                        }
                    }
                }
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Press any key to continue to view the Symbol Table.");
                Console.ReadKey();
                Console.Clear();
                searchTree.View();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        /********************************************************************
        *** FUNCTION <Search> ***
        *********************************************************************
        *** DESCRIPTION : <Search for the symbol using the BST> ***
        *** INPUT ARGS : <symbol> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <Symbol> ***
        ********************************************************************/
        public Symbol Search(string symbol)
        {
            if (symbol.Length > 5)
                symbol = symbol.Remove(5);
            var found = searchTree.Search(symbol);

            if (found != null)
                return found.Element;
            else
                throw new NullReferenceException("Symbol not found.");
        }
    }
}