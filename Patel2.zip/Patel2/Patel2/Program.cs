﻿using System;
using System.IO;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : OPERANDS***
*** DUE DATE : OCT 11, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program evaluates the operand field of an assembly
                  language statement. ***
********************************************************************/
namespace Patel2
{
    class Program
    {
        /********************************************************************
        *** FUNCTION <Main()> ***
        *********************************************************************
        *** DESCRIPTION : <Main Driver Program> ***
        *** INPUT ARGS : <args> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        static void Main(string[] args)
        {
            string fileName = args[0];
            while (!File.Exists(Path.Combine(Directory.GetCurrentDirectory(), fileName)))
            {
                Console.Write("Error -> Expression.txt file does not exist. Please enter a valid file name/file path: ");
                fileName = Console.ReadLine();
            }
            Console.Clear();
            SymbolTable read_txt = new SymbolTable();
            read_txt.ReadFile();
            Operands read_txt_1 = new Operands(read_txt);
            read_txt_1.ReadFile(fileName);
        }
    }
}