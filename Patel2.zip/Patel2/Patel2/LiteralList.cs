﻿using System;
/********************************************************************
*** NAME : Meet Patel***
*** CLASS : CSc 354 ***
*** ASSIGNMENT : OPERANDS***
*** DUE DATE : OCT 11, 2018***
*** INSTRUCTOR : Jason Werpy ***
*********************************************************************
*** DESCRIPTION : This program evaluates the operand field of an assembly
                  language statement. ***
********************************************************************/
namespace Patel2
{
    class ListNode
    {
        public Literal literal;
        public ListNode Next;
    }
    class LiteralList
    {
        private ListNode head;
        /********************************************************************
        *** FUNCTION <LiteralList> ***
        *********************************************************************
        *** DESCRIPTION : <Constructor> ***
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <None> ***
        ********************************************************************/
        public LiteralList()
        {
            head = null;
        }
        /********************************************************************
        *** FUNCTION <AppendNode> ***
        *********************************************************************
        *** DESCRIPTION : <The use of linked list to append/add node>
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void AppendNode(Literal literal)
        {
            ListNode newNode = new ListNode()
            {
                literal = literal,
                Next = null
            };
            ListNode nodePointer;
            if(head==null)
            {
                head = newNode;
            }
            else
            {
                nodePointer = head;
                while(nodePointer.Next!= null)
                {
                    nodePointer = nodePointer.Next;
                }
                nodePointer.Next = newNode;
            }
        }
        /********************************************************************
        *** FUNCTION <Find> ***
        *********************************************************************
        *** DESCRIPTION : <The use of linked list to find if name exists or not>
        *** INPUT ARGS : <literal> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <bool> ***
        ********************************************************************/
        public bool Find(Literal literal)
        {
            ListNode nodePointer = head;

            while (nodePointer != null)
            {
                if (nodePointer.literal.name == literal.name)
                    return true;
                nodePointer = nodePointer.Next;
            }
            return false;
        }
        /********************************************************************
        *** FUNCTION <View> ***
        *********************************************************************
        *** DESCRIPTION : <Function to view literal table>
        *** INPUT ARGS : <None> ***
        *** OUTPUT ARGS : <None> ***
        *** IN/OUT ARGS : <None> ***
        *** RETURN : <void> ***
        ********************************************************************/
        public void View()
        {
            Console.WriteLine("----------------LITERAL TABLE----------------------");
            Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10}", "Name", "Value", "Length", "Address");
            Console.WriteLine("---------------------------------------------------");
            ListNode nodePointer = head;
            while (nodePointer != null)
            {
                Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10}", nodePointer.literal.name, nodePointer.literal.value, nodePointer.literal.length, nodePointer.literal.address);
                nodePointer = nodePointer.Next;
            }
            Console.WriteLine("---------------------------------------------------");
        }
    }
}